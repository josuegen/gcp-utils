CREATE OR REPLACE TABLE `project-name.dataset-name.translation_log`(
    gcs_bucket_name STRING,
    input_script_uri STRING,
    output_script_uri STRING,
    batch_id STRING,
    step STRING,
    result STRING,
    error_message STRING,
    dry_run STRUCT<
      able_to_run BOOL,
      processing_bytes FLOAT64
    >,
    start_ts TIMESTAMP,
    end_ts TIMESTAMP,
    run_user STRING
)
CLUSTER BY batch_id, start_ts, end_ts, input_script_uri;