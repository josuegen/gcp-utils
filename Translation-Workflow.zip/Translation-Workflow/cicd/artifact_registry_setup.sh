# TODO (Developer): Set repository_name env variable
# TODO (Developer): Set location env variable
# TODO (Developer): Set GCP project ID

# export repository_name=translation-python-repo
# export location=us-central1
# export project=your-project

# Install twine which makes easier the publishing process
python3 -m pip install twine

# To set the default project, run the command:
gcloud config set project $project
gcloud auth application-default set-quota-project $project

# Create a new Python package repository
gcloud artifacts repositories create $repository_name \
    --repository-format=python \
    --location=$region \
    --description="BigQuery translation Python package repository"

# To simplify gcloud commands, set the default repository to quickstart-python-repo and the default location to us-central1.
# After the values are set, you do not need to specify them in gcloud commands that require a repository or a location.

#To set the repository, run the command:
gcloud config set artifacts/repository $repository_name

#To set the location, run the command:
gcloud config set artifacts/location $location