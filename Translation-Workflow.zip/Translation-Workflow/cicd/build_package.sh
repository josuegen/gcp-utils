# TODO (Developer): Set repository_name env variable
# TODO (Developer): Set location env variable
# TODO (Developer): Set GCP project ID

# export repository_name=translation-python-repo
# export location=us-central1
# export project=your-project

# Create a pip.conf file and include the following information in the file, if applicable:
# 1. URL of the Artifact Registry repository (in the index-url parameter)
# 2. Access credentials for the repository
# 3. Non-default pip installation options
cat >> ../pip.conf<< EOF
[global]
index-url = https://$location-python.pkg.dev/$project/$repository_name/simple/
EOF

# Add the operators/sensors as part of the library
cp -r ../samples/airflow/operators ../src/bigquery_translator
cp -r ../samples/airflow/sensors ../src/bigquery_translator

# Install build requeriment
python3 -m pip install --upgrade build

# Build package
python3 -m build ../