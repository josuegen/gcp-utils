# TODO (Developer): Set the Composer bucket name
# export composer_bucket=some-composer-bucket

# Add the operators/sensors as part of the library
cp -r ../samples/airflow/operators ../src/bigquery_translator
cp -r ../samples/airflow/sensors ../src/bigquery_translator

# Copy package source code into DAG bag
gcloud storage cp -r ../src/bigquery_translator gs://$composer_bucket/dags/