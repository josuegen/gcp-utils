# TODO (Developer): Set repository_name env variable
# TODO (Developer): Set location env variable
# TODO (Developer): Set GCP project ID

# export repository_name=translation-python-repo
# export location=us-central1
# export project=your-project

python3 -m twine upload --repository-url https://$location-python.pkg.dev/$project/$repository_name/ ../dist/*