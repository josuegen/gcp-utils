import pytest
import pandas as pd
import os
import re

class ConfigProcessor:
    def __init__(self, config, logger=None):
        self.config = config
        self.logger = logger if logger else self.create_mock_logger()  # Use a mock logger if none provided

    def create_mock_logger(self):
        class MockLogger:
            def info(self, message):
                print(f"INFO: {message}")
            def error(self, message):
                print(f"ERROR: {message}")
            def exception(self, message):
                print(f"EXCEPTION: {message}")
        return MockLogger()

    def replace_strings(self, lines, file_path):
        """Replaces strings in lines based on global, file-specific, and regex rules."""
        try:
            if not lines or not file_path:
                raise ValueError("Lines and file path cannot be empty.")

            file_name = os.path.splitext(os.path.basename(file_path))[0]
            self.logger.info(f"Starting replacements for file: {file_path}")

            lines = self.replace_global(lines)
            lines = self.replace_by_file(lines, file_name)
            lines = self.replace_by_regex(lines)

            self.logger.info(f"Replacements completed for file: {file_path}")
            return lines

        except ValueError as ve:
            self.logger.error(f"Input Error: {ve}")
            return None  # Or raise an exception

        except pd.errors.EmptyDataError as ee: # Catch empty CSV files
            self.logger.error(f"Error reading CSV: {ee}")
            return None

        except Exception as e:
            self.logger.exception(f"An unexpected error occurred: {e}")
            return None

    def replace_global(self, lines):
        """Replaces strings based on global rules."""
        global_replacements = self.config.get("replace_strings_global", [])
        for replacement in global_replacements:
            try:
                if not replacement["find"]:  # Check for empty "find"
                    self.logger.error("Error: 'find' argument cannot be empty. Skipping replacement.")
                    continue  # Skip to the next replacement
                lines = [line.replace(replacement["find"], replacement["replace"]) for line in lines]
            except (TypeError, AttributeError) as e:  # Catch if find/replace are missing
                self.logger.error(f"Error in global replacement: {e}. Skipping replacement.")
        return lines

    def replace_by_file(self, lines, file_name):
        """Replaces strings based on file-specific rules from a CSV."""
        file_replacements = self.config.get("replace_strings_by_file", {})
        csv_path = file_replacements.get("path")
        if not csv_path:
            return lines

        try:
            df = pd.read_csv(csv_path)
            df = df[df[file_replacements["fileName"]] == file_name]

            for _, row in df.iterrows():
                source = row[file_replacements["source"]]
                target = row[file_replacements["target"]]
                if not source: # Check if source is empty
    	            self.logger.error("Error: \'source\' argument cannot be empty. Skipping replacement.")
    	            continue
                lines = [line.replace(source, target) for line in lines]
            return lines

        except (KeyError, TypeError) as e: # Handle missing columns or bad config
            self.logger.error(f"Error in file-specific replacement configuration: {e}. Skipping file-specific replacements.")
            return lines # Important: return the lines even if the file replacement fails

        except FileNotFoundError:
            self.logger.error(f"CSV file not found at path: {csv_path}. Skipping file-specific replacements.")
            return lines

    def replace_by_regex(self, lines):
        """Replaces strings based on regex rules, treating all lines as a single string."""
        regex_replacements = self.config.get("replace_strings_regex", [])
        text = "\n".join(lines)  # Combine all lines into a single string
        for replacement in regex_replacements:
            pattern = replacement.get("pattern")
            replacement_text = replacement.get("replace")
            try:
                if pattern and replacement_text:
                    matches = re.findall(pattern, text, flags=re.IGNORECASE | re.MULTILINE) #buscar coincidencias
                    count_matches = len(matches)
                    self.logger.info(f"Matches found: {count_matches} for pattern: {pattern}")
                    text = re.sub(pattern, replacement_text, text, flags=re.IGNORECASE | re.MULTILINE)

            except re.error as e:  # Handle invalid regex patterns
                self.logger.error(f"Invalid regex pattern: {pattern}. Error: {e}. Skipping regex replacement.")
            except (TypeError, AttributeError) as e:  # Handle missing pattern/replace
                self.logger.error(f"Error in regex replacement: {e}. Skipping regex replacement.")

        return text.splitlines()

@pytest.fixture
def mock_logger():
    class MockLogger:
        def info(self, message):
            print(f"INFO: {message}")
        def error(self, message):
            print(f"ERROR: {message}")
        def exception(self, message):
            print(f"EXCEPTION: {message}")
    return MockLogger()

@pytest.fixture
def create_csv(tmp_path):
    """
    Fixture to create a temporary CSV file for testing file-specific replacements.
    """
    def _create_csv(filename, data):
        csv_file = tmp_path / filename
        df = pd.DataFrame(data)
        df.to_csv(csv_file, index=False)
        return str(csv_file)  # Return the path as a string
    return _create_csv

# Test Cases for replace_strings
def test_replace_strings_basic(mock_logger, create_csv):
    config = {
        "replace_strings_global": [{"find": "apple", "replace": "orange"}],
        "replace_strings_by_file": {
            "path": create_csv("data.csv", {
                "fileName": ["test_file"],
                "source": ["banana"],
                "target": ["grape"]
            }),
            "fileName": "fileName",
            "source": "source",
            "target": "target"
        },
        "replace_strings_regex": [{"pattern": r"f\w{2}", "replace": "bar"}]
    }
    processor = ConfigProcessor(config, mock_logger)
    lines = ["This is an apple and a banana.", "Another line with foo."]
    file_path = "test_file.txt"
    expected = ["This is an orange and a grape.", "Another line with bar."]
    result = processor.replace_strings(lines, file_path)
    assert result == expected

def test_replace_strings_empty_input(mock_logger):
    processor = ConfigProcessor({}, mock_logger)
    lines = []
    file_path = "test_file.txt"
    result = processor.replace_strings(lines, file_path)
    assert result is None

def test_replace_strings_empty_file_path(mock_logger):
    processor = ConfigProcessor({}, mock_logger)
    lines = ["test line"]
    file_path = ""
    result = processor.replace_strings(lines, file_path)
    assert result is None

def test_replace_strings_no_replacements(mock_logger):
    config = {}
    processor = ConfigProcessor(config, mock_logger)
    lines = ["This is a test line."]
    file_path = "test_file.txt"
    expected = ["This is a test line."]
    result = processor.replace_strings(lines, file_path)
    assert result == expected

def test_replace_strings_file_not_found(mock_logger):
    config = {
        "replace_strings_by_file": {
            "path": "nonexistent.csv",
             "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config, mock_logger)
    lines = ["test line"]
    file_path = "test_file.txt"
    expected = ["test line"]
    result = processor.replace_strings(lines, file_path)
    assert result == expected

def test_replace_strings_empty_csv(mock_logger, create_csv):
    config = {
        "replace_strings_by_file": {
            "path": create_csv("empty.csv", {"fileName": [], "source": [], "target": []}),
            "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config, mock_logger)
    lines = ["test line"]
    file_path = "test_file.txt"
    expected = ["test line"]
    result = processor.replace_strings(lines, file_path)
    assert result == expected

def test_replace_strings_invalid_config(mock_logger, create_csv):
    config = {
        "replace_strings_by_file": {
            "path": create_csv("data.csv", {"file_name": ["test_file"], "source": ["banana"], "target": ["grape"]}),
            "fileName": "wrong_file_name",  # Use a wrong key
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config, mock_logger)
    lines = ["This is a test line with banana"]
    file_path = "test_file.txt"
    expected = ["This is a test line with banana"]
    result = processor.replace_strings(lines, file_path)
    assert result == expected

# Test Cases for replace_global
def test_replace_global_basic():
    config = {"replace_strings_global": [{"find": "apple", "replace": "orange"}]}
    processor = ConfigProcessor(config)
    lines = ["This is an apple.", "Another apple here."]
    expected = ["This is an orange.", "Another orange here."]
    assert processor.replace_global(lines) == expected

def test_replace_global_case_sensitive():
    config = {"replace_strings_global": [{"find": "Apple", "replace": "Orange"}]}
    processor = ConfigProcessor(config)
    lines = ["This is an Apple.", "Another apple here."]
    expected = ["This is an Orange.", "Another apple here."]
    assert processor.replace_global(lines) == expected

def test_replace_global_multiple_replacements():
    config = {"replace_strings_global": [{"find": "apple", "replace": "orange"}, {"find": "banana", "replace": "grape"}]}
    processor = ConfigProcessor(config)
    lines = ["This is an apple and a banana.", "Another banana, and an apple."]
    expected = ["This is an orange and a grape.", "Another grape, and an orange."]
    assert processor.replace_global(lines) == expected

def test_replace_global_no_replacements():
    config = {}
    processor = ConfigProcessor(config)
    lines = ["This is an apple.", "Another banana here."]
    expected = ["This is an apple.", "Another banana here."]
    assert processor.replace_global(lines) == expected

def test_replace_global_empty_lines():
    config = {"replace_strings_global": [{"find": "apple", "replace": "orange"}]}
    processor = ConfigProcessor(config)
    lines = []
    expected = []
    assert processor.replace_global(lines) == expected

def test_replace_global_empty_find_or_replace(mock_logger):
    config = {"replace_strings_global": [{"find": "", "replace": "orange"}, {"find": "apple", "replace": ""}]}
    processor = ConfigProcessor(config, mock_logger)
    lines = ["This is an apple.", "Another banana here."]
    expected = ["This is an .", "Another banana here."] #  replace with empty string does nothing
    assert processor.replace_global(lines) == expected

def test_replace_global_find_not_found():
    config = {"replace_strings_global": [{"find": "grape", "replace": "orange"}]}
    processor = ConfigProcessor(config)
    lines = ["This is an apple.", "Another banana here."]
    expected = ["This is an apple.", "Another banana here."]
    assert processor.replace_global(lines) == expected

# Test Cases for replace_by_file
def test_replace_by_file_basic(create_csv):
    csv_path = create_csv("data.csv", {
        "fileName": ["my_file"],
        "source": ["old"],
        "target": ["new"]
    })
    config = {
        "replace_strings_by_file": {
            "path": csv_path,
            "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines = ["This is old.", "Another old here."]
    file_name = "my_file"
    expected = ["This is new.", "Another new here."]
    assert processor.replace_by_file(lines, file_name) == expected

def test_replace_by_file_multiple_rows(create_csv):
    csv_path = create_csv("data.csv", {
        "fileName": ["my_file", "my_file"],
        "source": ["old1", "old2"],
        "target": ["new1", "new2"]
    })
    config = {
        "replace_strings_by_file": {
            "path": csv_path,
             "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines = ["This is old1 and old2.", "Another old2 here."]
    file_name = "my_file"
    expected = ["This is new1 and new2.", "Another new2 here."]
    assert processor.replace_by_file(lines, file_name) == expected

def test_replace_by_file_different_file_names(create_csv):
    csv_path = create_csv("data.csv", {
        "fileName": ["file1", "file2"],
        "source": ["old", "old"],
        "target": ["new1", "new2"]
    })
    config = {
        "replace_strings_by_file": {
            "path": csv_path,
             "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines1 = ["This is old."]
    lines2 = ["This is old."]
    file_name1 = "file1"
    file_name2 = "file2"
    expected1 = ["This is new1."]
    expected2 = ["This is new2."]
    assert processor.replace_by_file(lines1, file_name1) == expected1
    assert processor.replace_by_file(lines2, file_name2) == expected2

def test_replace_by_file_no_matching_file(create_csv):
    csv_path = create_csv("data.csv", {
        "fileName": ["other_file"],
        "source": ["old"],
        "target": ["new"]
    })
    config = {
        "replace_strings_by_file": {
            "path": csv_path,
             "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines = ["This is old."]
    file_name = "my_file"
    expected = ["This is old."]
    assert processor.replace_by_file(lines, file_name) == expected

def test_replace_by_file_empty_lines():
    config = {
        "replace_strings_by_file": {
            "path": "nonexistent.csv",
             "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines = []
    file_name = "my_file"
    expected = []
    assert processor.replace_by_file(lines, file_name) == expected

def test_replace_by_file_empty_csv(create_csv):
    csv_path = create_csv("empty.csv", {"fileName": [], "source": [], "target": []})
    config = {
        "replace_strings_by_file": {
            "path": csv_path,
             "fileName": "fileName",
            "source": "source",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines = ["This is old"]
    file_name = "my_file"
    expected = ["This is old"]
    assert processor.replace_by_file(lines, file_name) == expected

def test_replace_by_file_missing_config_key(create_csv):
    csv_path = create_csv("data.csv", {"fileName": ["my_file"], "source": ["old"], "target": ["new"]})
    config = {
        "replace_strings_by_file": {
            "path": csv_path,
            "fileName": "fileName",
            "target": "target"
        }
    }
    processor = ConfigProcessor(config)
    lines = ["This is old"]
    file_name = "my_file"
    expected = ["This is old"]

    result = processor.replace_by_file(lines, file_name)
    assert result == expected

# Test Cases for replace_by_regex
def test_replace_regex_basic():
    config = {"replace_strings_regex": [{"pattern": r"apple", "replace": "orange"}]}
    processor = ConfigProcessor(config)
    lines = ["This is an apple.", "Another apple here."]
    expected = ["This is an orange.", "Another orange here."]
    assert processor.replace_by_regex(lines) == expected

def test_replace_regex_case_insensitive():
    config = {"replace_strings_regex": [{"pattern": r"Apple", "replace": "Orange"}]}
    processor = ConfigProcessor(config)
    lines = ["This is an Apple.", "Another apple here."]
    expected = ["This is an Orange.", "Another Orange here."]
    assert processor.replace_by_regex(lines) == expected

def test_replace_regex_multiple_lines():
    config = {"replace_strings_regex": [{"pattern": r"line\s\d", "replace": "replaced line"}]}
    processor = ConfigProcessor(config)
    lines = ["This is line 1.", "Another line 2 here."]
    expected = ["This is replaced line.", "Another replaced line here."]
    assert processor.replace_by_regex(lines) == expected

def test_replace_regex_no_replacements():
    config = {}
    processor = ConfigProcessor(config)
    lines = ["This is an apple.", "Another banana here."]
    expected = ["This is an apple.", "Another banana here."]
    assert processor.replace_by_regex(lines) == expected

def test_replace_regex_empty_lines():
    config = {"replace_strings_regex": [{"pattern": r"apple", "replace": "orange"}]}
    processor = ConfigProcessor(config)
    lines = []
    expected = []
    assert processor.replace_by_regex(lines) == expected

def test_replace_regex_special_characters():
    config = {"replace_strings_regex": [{"pattern": r"\d+", "replace": "#"}]}
    processor = ConfigProcessor(config)
    lines = ["This is line 123.", "Another line 456 here."]
    expected = ["This is line #.", "Another line # here."]
    assert processor.replace_by_regex(lines) == expected

def test_replace_regex_group_capture():
    config = {"replace_strings_regex": [{"pattern": r"(\w+) (\w+)", "replace": r"\2 \1"}]}
    processor = ConfigProcessor(config)
    lines = ["Swap this around.", "Another test here."]
    expected = ["this Swap around.", "test Another here."]
    assert processor.replace_by_regex(lines) == expected


