import pytest

class ConfigProcessor:
    def __init__(self, config, logger=None):
        self.config = config
        self.logger = logger

    def remove_lines(self, lines):
        """Removes lines containing specified substrings."""
        to_remove = self.config.get("remove_lines", [])
        return [line for line in lines if not any(substring.lower() in line.lower() for substring in to_remove)]

    def remove_groups(self, lines):
        """Removes groups of lines enclosed by start and end markers."""
        groups = self.config.get("remove_groups", [])
        result = []
        skip = False

        for line in lines:
            if any(group["start"].lower() in line.lower() for group in groups):
                skip = True
            if not skip:
                result.append(line)
            if any(group["end"].lower() in line.lower() for group in groups):
                skip = False
        return result

    def add_new_lines(self, lines):
        """Adds new lines at specified positions."""
        to_add = self.config.get("add_lines", [])
        print(len(lines))
        for item in to_add:
            string = item["string"]
            position = item.get("position")
            print(string)
            if position is not None:
                if position < 1 or position > len(lines):
                    if self.logger:
                        self.logger.error(f"Invalid position {position} for adding line: {string}")
                    continue  # Skip to the next item in the loop
                position -= 1
            else:
                position = len(lines)

            try:  # Handle invalid positions
                lines.insert(position, string + "\n")
            except IndexError:
                if self.logger:
                    self.logger.error(f"Invalid position {position} for adding line: {string}")
        return lines

@pytest.fixture
def mock_logger():
    class MockLogger:
        def error(self, message):
            print(f"ERROR: {message}")  # Simulate logging
    return MockLogger()

def test_remove_lines_basic():
    config = {"remove_lines": ["test"]}
    processor = ConfigProcessor(config)
    lines = ["This is a test line", "Another line", "No test here"]
    expected = ["Another line"]
    assert processor.remove_lines(lines) == expected

def test_remove_lines_case_insensitive():
    config = {"remove_lines": ["Test"]}
    processor = ConfigProcessor(config)
    lines = ["This is a test line", "Another line", "No TEST here"]
    expected = ["Another line"]
    assert processor.remove_lines(lines) == expected

def test_remove_lines_multiple_substrings():
    config = {"remove_lines": ["test", "another"]}
    processor = ConfigProcessor(config)
    lines = ["This is a test line", "Another line", "No test here", "Clean"]
    expected = ["Clean"]
    assert processor.remove_lines(lines) == expected

def test_remove_lines_empty_config():
    config = {}
    processor = ConfigProcessor(config)
    lines = ["This is a test line", "Another line", "No test here"]
    expected = ["This is a test line", "Another line", "No test here"]
    assert processor.remove_lines(lines) == expected

def test_remove_lines_empty_lines():
    config = {"remove_lines": ["test"]}
    processor = ConfigProcessor(config)
    lines = []
    expected = []
    assert processor.remove_lines(lines) == expected

def test_remove_lines_substring_not_present():
    config = {"remove_lines": ["nonexistent"]}
    processor = ConfigProcessor(config)
    lines = ["This is a test line", "Another line", "No test here"]
    expected = ["This is a test line", "Another line", "No test here"]
    assert processor.remove_lines(lines) == expected

def test_remove_lines_substring_at_start_and_end():
    config = {"remove_lines": ["start", "end"]}
    processor = ConfigProcessor(config)
    lines = ["start of line", "middle", "end of line", "no match"]
    expected = ["middle", "no match"]
    assert processor.remove_lines(lines) == expected

def test_remove_groups_basic():
    config = {"remove_groups": [{"start": "start", "end": "end"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "start group", "line2", "end group", "line3"]
    expected = ["line1", "line3"]
    assert processor.remove_groups(lines) == expected

def test_remove_groups_nested():
    config = {"remove_groups": [{"start": "start group", "end": "end group"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "start group", "start nested", "line2", "end nested", "line3", "end group", "line4"]
    expected = ["line1", "line4"]
    assert processor.remove_groups(lines) == expected

def test_remove_groups_multiple_groups():
    config = {"remove_groups": [{"start": "start1", "end": "end1"}, {"start": "start2", "end": "end2"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "start1 group", "line2", "end1 group", "line3", "start2 group", "line4", "end2 group", "line5"]
    expected = ["line1", "line3", "line5"]
    assert processor.remove_groups(lines) == expected

def test_remove_groups_case_insensitive():
    config = {"remove_groups": [{"start": "START", "end": "END"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "start group", "line2", "end group", "line3"]
    expected = ["line1", "line3"]
    assert processor.remove_groups(lines) == expected

def test_remove_groups_empty_config():
    config = {}
    processor = ConfigProcessor(config)
    lines = ["line1", "start group", "line2", "end group", "line3"]
    expected = ["line1", "start group", "line2", "end group", "line3"]
    assert processor.remove_groups(lines) == expected

def test_remove_groups_no_end_marker():
    config = {"remove_groups": [{"start": "start", "end": "end"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "start group", "line2", "line3"]
    expected = ["line1"]
    print(lines)
    assert processor.remove_groups(lines) == expected

def test_remove_groups_no_start_marker():
    config = {"remove_groups": [{"start": "start", "end": "end"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "line2", "end group", "line3"]
    expected = ["line1", "line2", "end group", "line3"]
    assert processor.remove_groups(lines) == expected

def test_add_new_lines_basic():
    config = {"add_lines": [{"string": "new line", "position": 2}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "line3"]
    expected = ["line1", "new line\n", "line3"]
    assert processor.add_new_lines(lines) == expected

def test_add_new_lines_end_position():
    config = {"add_lines": [{"string": "new line"}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "line2"]
    expected = ["line1", "line2", "new line\n"]
    assert processor.add_new_lines(lines) == expected

def test_add_new_lines_multiple_lines():
    config = {"add_lines": [{"string": "lineA", "position": 1}, {"string": "lineB", "position": 3}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "line2", "line4"]
    expected = ["lineA\n", "line1", "lineB\n", "line2", "line4"]
    assert processor.add_new_lines(lines) == expected

def test_add_new_lines_invalid_position(mock_logger):
    config = {"add_lines": [{"string": "new line", "position": 10}]}
    processor = ConfigProcessor(config, logger=mock_logger)
    lines = ["line1", "line2"]
    expected = ["line1", "line2"]	
    assert processor.add_new_lines(lines) == expected

def test_add_new_lines_empty_config():
    config = {}
    processor = ConfigProcessor(config)
    lines = ["line1", "line2"]
    expected = ["line1", "line2"]
    assert processor.add_new_lines(lines) == expected

def test_add_new_lines_position_zero():
    config = {"add_lines": [{"string": "new line", "position": 0}]}
    processor = ConfigProcessor(config)
    lines = ["line1", "line2"]
    expected = ["line1", "line2"]
    assert processor.add_new_lines(lines) == expected



