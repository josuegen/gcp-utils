#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
    This module contains operators to:
    - Submit queries for translation against the BigQuery translations API
    - Dry run translated queries

"""

from __future__ import annotations

from typing import TYPE_CHECKING

from functools import cached_property

from airflow.models import BaseOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.common.links.storage import StorageLink
from airflow.providers.google.common.hooks.base_google import GoogleBaseHook

from bigquery_translator import workflow


if TYPE_CHECKING:
    from collections.abc import Sequence
    from airflow.utils.context import Context


class BigQueryTranslateQueriesOperator(BaseOperator):

    template_fields: Sequence[str] = (
        "bucket_name",
        "location",
        "input_prefix",
        "output_prefix",
        "gcp_conn_id",
        "impersonation_chain",
    )

    operator_extra_links = (StorageLink(),)
    # template_fields_renderers = {"headers": "json", "data": "py"}
    template_ext: Sequence[str] = ()
    ui_color = "#fce49f"

    def __init__(
        self,
        *,
        location: str,
        bucket_name: str,
        input_prefix: str | None = None,
        output_prefix: str | None = None,
        gcp_conn_id: str = "google_cloud_default",
        impersonation_chain: str | Sequence[str] | None = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.location = location
        self.bucket_name = bucket_name
        self.input_prefix = input_prefix
        self.gcp_conn_id = gcp_conn_id
        self.impersonation_chain = impersonation_chain
        self.output_prefix = output_prefix

    def execute(self, context: Context):
        task_instance = context.get("ti")

        # Create an GoogleBaseHook
        gcp_hook = GoogleBaseHook(
            gcp_conn_id=self.gcp_conn_id,
            impersonation_chain=self.impersonation_chain
        )

        StorageLink.persist(
            context=context,
            task_instance=self,
            uri=self.bucket_name,
            project_id=gcp_hook.project_id
        )

        translation_job_id = workflow.execute_bigquery_translation(
            project_id=gcp_hook.project_id,
            gcs_bucket=self.bucket_name,
            location=self.location,
            input_prefix=self.input_prefix,
            output_prefix=self.output_prefix,
            access_token=gcp_hook._get_access_token()
        )

        task_instance.xcom_push(
            key="translation_job_id",
            value=translation_job_id
        )


class BigQueryDryRunQueriesOperator(BaseOperator):

    template_fields: Sequence[str] = (
        "bucket_name",
        "input_prefix",
        "match_glob",
        "bigquery_log_table",
        "input_extension",
        "gcp_conn_id",
        "impersonation_chain",
    )

    operator_extra_links = (StorageLink(),)
    # template_fields_renderers = {"headers": "json", "data": "py"}
    template_ext: Sequence[str] = ()
    ui_color = "#f2a5a5"

    def __init__(
        self,
        *,
        bucket_name: str,
        input_prefix: str | None = None,
        match_glob: str | None = None,
        bigquery_log_table: str,
        input_extension: str = ".sql",
        gcp_conn_id: str = "google_cloud_default",
        impersonation_chain: str | Sequence[str] | None = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.bucket_name = bucket_name
        self.input_prefix = input_prefix
        self.match_glob = match_glob
        self.bigquery_log_table = bigquery_log_table
        self.input_extension = input_extension
        self.gcp_conn_id = gcp_conn_id
        self.impersonation_chain = impersonation_chain

    @cached_property
    def gcs_hook(self) -> GCSHook:
        """Create and return a GCSHook."""
        return GCSHook(
            gcp_conn_id=self.gcp_conn_id,
            impersonation_chain=self.impersonation_chain
        )

    @cached_property
    def gcp_hook(self) -> GoogleBaseHook:
        """Create and return a GoogleBaseHook."""
        return GoogleBaseHook(
            gcp_conn_id=self.gcp_conn_id,
            impersonation_chain=self.impersonation_chain
        )

    def execute(self, context: Context):
        # List files in GCS
        if self.match_glob:
            self.log.info(
                "Getting list of the files. Bucket: %s; MatchGlob: %s; Prefix(es): %s",
                self.bucket_name,
                self.match_glob,
                self.input_prefix,
            )
        else:
            self.log.info(
                "Getting list of the files. Bucket: %s; Prefix(es): %s",
                self.bucket_name,
                self.input_prefix,
            )

        StorageLink.persist(
            context=context,
            task_instance=self,
            uri=self.bucket_name,
            project_id=self.gcs_hook.project_id,
        )

        files_to_process = self.gcs_hook.list(
            bucket_name=self.bucket_name,
            prefix=self.input_prefix,
            match_glob=self.match_glob
        )

        workflow.dry_run_task_airflow(
            bucket=self.bucket_name,
            input_prefix=self.input_prefix,
            bigquery_log_table_id=self.bigquery_log_table,
            input_file_list=files_to_process,
            input_extension=self.input_extension,
            credentials=self.gcp_hook.get_credentials(),
            username=self.gcp_hook._get_credentials_email,
            context=context
        )
