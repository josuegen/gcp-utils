#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
    This module contains operator to (pre/post) adjust files
    in Teradata to BigQuery translation.
"""

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING

from airflow.models import BaseOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.common.hooks.base_google import GoogleBaseHook
from airflow.providers.google.common.links.storage import StorageLink

from bigquery_translator import workflow


if TYPE_CHECKING:
    from collections.abc import Sequence
    from airflow.utils.context import Context


class BigQueryOptimizeQueriesOperator(BaseOperator):

    template_fields: Sequence[str] = (
        "bucket_name",
        "location",
        "input_prefix",
        "output_prefix",
        "model_name",
        "config_prompt_path",
        "bigquery_log_table",
        "gcp_conn_id",
        "impersonation_chain",
    )

    operator_extra_links = (StorageLink(),)
    # template_fields_renderers = {"headers": "json", "data": "py"}
    template_ext: Sequence[str] = ()
    ui_color = "#99bdf7"

    def __init__(
        self,
        *,
        bucket_name: str,
        location: str,
        match_glob: str | None = None,
        input_prefix: str | None = None,
        output_prefix: str | None = None,
        model_name: str = "gemini-2.0-flash-001",
        config_prompt_path: str,
        bigquery_log_table: str | None = None,
        gcp_conn_id: str = "google_cloud_default",
        impersonation_chain: str | Sequence[str] | None = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.bucket_name = bucket_name
        self.location = location
        self.match_glob = match_glob
        self.input_prefix = input_prefix
        self.output_prefix = output_prefix
        self.model_name = model_name
        self.config_prompt_path = config_prompt_path
        self.bigquery_log_table = bigquery_log_table
        self.gcp_conn_id = gcp_conn_id
        self.impersonation_chain = impersonation_chain

    @cached_property
    def gcs_hook(self) -> GCSHook:
        """Create and return a GCSHook."""
        return GCSHook(
            gcp_conn_id=self.gcp_conn_id,
            impersonation_chain=self.impersonation_chain
        )

    @cached_property
    def gcp_hook(self) -> GoogleBaseHook:
        """Create and return a GoogleBaseHook."""
        return GoogleBaseHook(
            gcp_conn_id=self.gcp_conn_id,
            impersonation_chain=self.impersonation_chain
        )

    def execute(self, context: Context):
        # List files in GCS
        if self.match_glob:
            self.log.info(
                "Getting list of the files. Bucket: %s; MatchGlob: %s; Prefix(es): %s",
                self.bucket_name,
                self.match_glob,
                self.input_prefix,
            )
        else:
            self.log.info(
                "Getting list of the files. Bucket: %s; Prefix(es): %s",
                self.bucket_name,
                self.input_prefix,
            )

        StorageLink.persist(
            context=context,
            task_instance=self,
            uri=self.bucket_name,
            project_id=self.gcs_hook.project_id,
        )

        files_to_process = self.gcs_hook.list(
            bucket_name=self.bucket_name,
            prefix=self.input_prefix,
            match_glob=self.match_glob
        )

        workflow.optimize_queries_airflow(
            project_id=self.gcp_hook.project_id,
            location=self.location,
            bucket=self.bucket_name,
            output_prefix=self.output_prefix,
            input_files_list=files_to_process,
            model_name=self.model_name,
            config_prompt_path=self.config_prompt_path,
            credentials=self.gcp_hook.get_credentials(),
            bigquery_log_table=self.bigquery_log_table,
            context=context,
        )
