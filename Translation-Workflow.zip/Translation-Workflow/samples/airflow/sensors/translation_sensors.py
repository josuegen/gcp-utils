#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
    This module contains sensors to wait for the completion of
    BigQuery translation jobs
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from google.cloud.storage.retry import DEFAULT_RETRY

from airflow.configuration import conf
from airflow.providers.google.common.hooks.base_google import GoogleBaseHook
from airflow.sensors.base import BaseSensorOperator

if TYPE_CHECKING:
    from google.api_core.retry import Retry

    from airflow.utils.context import Context

from bigquery_translator import workflow


class BigQueryTranslationJobSensor(BaseSensorOperator):

    template_fields: Sequence[str] = (
        "location",
        "translation_job_id",
        "google_cloud_conn_id",
        "impersonation_chain",
    )

    ui_color = "#f0eee4"

    def __init__(
        self,
        *,
        location: str,
        translation_job_id: str,
        google_cloud_conn_id: str = "google_cloud_default",
        impersonation_chain: str | Sequence[str] | None = None,
        retry: Retry = DEFAULT_RETRY,
        deferrable: bool = conf.getboolean(
            "operators",
            "default_deferrable",
            fallback=False
        ),
        **kwargs,
    ) -> None:

        super().__init__(**kwargs)

        self.location = location
        self.translation_job_id = translation_job_id
        self.google_cloud_conn_id = google_cloud_conn_id
        self._matches: bool = False
        self.impersonation_chain = impersonation_chain
        self.retry = retry
        self.deferrable = deferrable

    def poke(self, context: Context) -> bool:
        self.log.info(
            "Checking status of Job ID: %s",
            self.translation_job_id
        )

        # Create an GoogleBaseHook
        gcp_hook = GoogleBaseHook(
            gcp_conn_id=self.google_cloud_conn_id,
            impersonation_chain=self.impersonation_chain
        )

        # TODO: Incorporate translation results from the API response
        # https://cloud.google.com/bigquery/docs/reference/migration/rest/v2/projects.locations.workflows#gcsreportlogmessage
        translation_status_response = workflow.poke_translation_status(
            project_id=gcp_hook.project_id,
            location=self.location,
            translation_job_id=self.translation_job_id,
            access_token=gcp_hook._get_access_token()
        )

        return workflow.check_translation_status_response(
            response=translation_status_response
        )
