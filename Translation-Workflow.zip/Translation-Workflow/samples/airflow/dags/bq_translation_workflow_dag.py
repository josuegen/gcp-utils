"""
   Copyright 2024 Google

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
"""


from airflow import DAG
from airflow.utils.dates import days_ago

from bigquery_translator.operators.adjust import TranslationAdjustFilesOperator
from bigquery_translator.operators.translation import (
    BigQueryTranslateQueriesOperator,
    BigQueryDryRunQueriesOperator
)
from bigquery_translator.sensors.translation_sensors import (
     BigQueryTranslationJobSensor
)
from bigquery_translator.operators.optimization import (
    BigQueryOptimizeQueriesOperator
)

from datetime import timedelta


# Define default arguments for the DAG
DEFAULT_DAG_ARGS = {
    "owner": "google",
    "depends_on_past": False,
    "start_date": days_ago(1),
    "retries": 5,
    "retry_delay": timedelta(minutes=5)
}

# Define the DAG
with DAG(
    dag_id="bq_translation_workflow",
    default_args=DEFAULT_DAG_ARGS,
    description="A DAG to preprocess, translate, and postprocess SQL files for custom translations",
    schedule_interval=None,
    catchup=False,
    tags=["bq_translation", "sql_preprocessing"],  # Added tags for better DAG categorization
) as dag:
    # [START dag_parameters]
    # Define DAG parameters using Airflow Macros and default values
    PROJECT_ID = '{{(dag_run.conf["project_id"] if "project_id" in dag_run.conf.keys() else "" ) }}'
    PROJECT_BQ_LOG = '{{(dag_run.conf["project_bigquery_log"] if "project_bigquery_log" in dag_run.conf.keys() else "" ) }}'
    DATASET_BQ_LOG = '{{(dag_run.conf["dataset_bigquery_log"] if "dataset_bigquery_log" in dag_run.conf.keys() else "" ) }}'
    LOCATION = '{{(dag_run.conf["location"] if "location" in dag_run.conf.keys() else "" ) }}'
    GCS_BUCKET = '{{(dag_run.conf["gcs_bucket"] if "gcs_bucket" in dag_run.conf.keys() else "" ) }}'
    FOLDER_INPUT = '{{(dag_run.conf["folder_input"] if "folder_input" in dag_run.conf.keys() else "" ) }}'
    FOLDER_OUTPUT_PRE_PROCESSING =  '{{(dag_run.conf["folder_output_pre_processing"] if "folder_output_pre_processing" in dag_run.conf.keys() else "" ) }}'
    FOLDER_OUTPUT_TRANSLATION =  '{{(dag_run.conf["folder_output_translation"] if "folder_output_translation" in dag_run.conf.keys() else "" ) }}'
    FOLDER_OUTPUT_POST_PROCESSING =  '{{(dag_run.conf["folder_output_post_processing"] if "folder_output_post_processing" in dag_run.conf.keys() else "" ) }}'
    FOLDER_OUTPUT_OPTIMIZED =  '{{(dag_run.conf["folder_output_optimized"] if "folder_output_optimized" in dag_run.conf.keys() else "" ) }}'
    PRE_PROCESSING_YAML_PATH = '{{(dag_run.conf["pre_processing_yaml_path"] if "pre_processing_yaml_path" in dag_run.conf.keys() else "" ) }}'
    POST_PROCESSING_YAML_PATH = '{{(dag_run.conf["post_processing_yaml_path"] if "post_processing_yaml_path" in dag_run.conf.keys() else "" ) }}'
    INPUT_EXTENSION = '{{(dag_run.conf["input_extension"] if "input_extension" in dag_run.conf.keys() else ".bteq" ) }}'
    OUTPUT_EXTENSION = '{{(dag_run.conf["output_extension"] if "output_extension" in dag_run.conf.keys() else ".sql" ) }}'
    MODEL_NAME = '{{(dag_run.conf["model_name"] if "model_name" in dag_run.conf.keys() else "" ) }}'
    CONFIG_PROMPT_PATH = '{{(dag_run.conf["config_prompt_path"] if "config_prompt_path" in dag_run.conf.keys() else "" ) }}'
    USERNAME = '{{(dag_run.conf["username"] if "username" in dag_run.conf.keys() else "" ) }}'
    # [END dag_parameters]

    preprocessing_files_task = TranslationAdjustFilesOperator(
        task_id="preprocessing_files",
        bucket_name=GCS_BUCKET,
        input_prefix=FOLDER_INPUT,
        output_prefix=FOLDER_OUTPUT_PRE_PROCESSING,
        config_file_blob_name=PRE_PROCESSING_YAML_PATH,
        bigquery_log_table="{{ var.value.bigquery_translation_log_table }}",
        impersonation_chain="{{ var.value.target_service_account}}"
    )

    translating_files_task = BigQueryTranslateQueriesOperator(
        task_id="execute_bigquery_translation",
        location=LOCATION,
        input_prefix=FOLDER_OUTPUT_PRE_PROCESSING,
        output_prefix=FOLDER_OUTPUT_TRANSLATION,
        bucket_name=GCS_BUCKET,
        # bigquery_log_table="{{ var.value.bigquery_translation_log_table }}",
        impersonation_chain="{{ var.value.target_service_account}}"
    )

    translating_files_sensor_task = BigQueryTranslationJobSensor(
        task_id="sense_bigquery_translation",
        location=LOCATION,
        translation_job_id="{{ ti.xcom_pull(task_ids='execute_bigquery_translation', key='translation_job_id') }}",
        impersonation_chain="{{ var.value.target_service_account}}"
    )

    postprocessing_files_task = TranslationAdjustFilesOperator(
        task_id="postprocessing_files",
        bucket_name=GCS_BUCKET,
        input_prefix=f"{FOLDER_OUTPUT_TRANSLATION}sql/",
        output_prefix=FOLDER_OUTPUT_POST_PROCESSING,
        config_file_blob_name=POST_PROCESSING_YAML_PATH,
        output_extension=OUTPUT_EXTENSION,
        input_extension=OUTPUT_EXTENSION,
        bigquery_log_table="{{ var.value.bigquery_translation_log_table }}",
        impersonation_chain="{{ var.value.target_service_account}}"
    )

    dry_run_queries_task = BigQueryDryRunQueriesOperator(
        task_id="dry_run_queries",
        bucket_name=GCS_BUCKET,
        input_prefix=f"{FOLDER_OUTPUT_TRANSLATION}sql/",
        bigquery_log_table="{{ var.value.bigquery_translation_log_table }}",
        impersonation_chain="{{ var.value.target_service_account}}"
    )

    optimize_queries_task = BigQueryOptimizeQueriesOperator(
        task_id="optimize_queries",
        bucket_name=GCS_BUCKET,
        location=LOCATION,
        input_prefix=f"{FOLDER_OUTPUT_TRANSLATION}sql/",
        output_prefix=FOLDER_OUTPUT_OPTIMIZED,
        model_name=MODEL_NAME,
        config_prompt_path=CONFIG_PROMPT_PATH,
        bigquery_log_table="{{ var.value.bigquery_translation_log_table }}",
        impersonation_chain="{{ var.value.target_service_account}}"
    )

    (
        preprocessing_files_task >>
        translating_files_task >>
        translating_files_sensor_task >>
        postprocessing_files_task >>
        dry_run_queries_task >>
        optimize_queries_task
    )
