# BigQuery Translation Workflow DAG

## Overview

This Airflow DAG automates the process of translating SQL scripts from Teradata syntax to BigQuery SQL syntax. It includes preprocessing, translation using Google Cloud's BigQuery Translation Service, postprocessing, dry run validation, and optional query optimization using Vertex AI's Gemini models.

The DAG is designed to be configurable and can be adapted for various SQL translation needs. It leverages Google Cloud services like Google Cloud Storage (GCS), BigQuery, Secret Manager, and Vertex AI.

## Modules

The project consists of the following Python modules located in the `utils` directory and the main DAG definition file:

-   **`dags/bq_translation_workflow.py`**: The main Airflow DAG definition file. It orchestrates the entire SQL translation workflow, defining tasks for file listing, preprocessing, translation, postprocessing, dry run, query optimization, and cleanup.

-   **`utils/dry_run_query.py`**:
    -   **`QueryDryRunner` Class**: This module provides the `QueryDryRunner` class, responsible for performing dry runs of BigQuery SQL queries.
    -   It initializes with Google Cloud credentials and offers methods to:
        -   `dry_run_query(bucket_name, folder_path, sql_file_name, dag_run_user)`: Executes a dry run for a single SQL query file stored in GCS, retrieving the query content, performing the dry run using BigQuery API, and collecting metadata (execution statistics, errors, etc.). It also captures the Airflow DAG run's user for logging purposes.
        -   `dry_run_all_queries(bucket_name, folder_path, sql_files, dry_run_log_table_name, dag_run_user)`: Iterates through a list of SQL files, performs dry runs for each using `dry_run_query`, and then logs the collected metadata to a specified BigQuery table. It handles potential errors during dry runs and BigQuery insert operations, raising `AirflowFailException` to signal DAG failure in case of critical issues.

-   **`utils/query_optimizer.py`**:
    -   **`QueryOptimizer` Class**: Defines the `QueryOptimizer` class for leveraging Vertex AI's Gemini models to optimize BigQuery SQL queries.
    -   Initialization (`__init__`) sets up Vertex AI, loads a prompt for optimization from GCS (if configured), and prepares the Gemini model.
    -   `load_prompt()`: Loads the optimization prompt from a YAML file in GCS, used to guide the Gemini model's optimization process.
    -   `optimize_sql(sql_query)`: Takes a SQL query as input, constructs a prompt by combining a base prompt (either loaded from GCS or a default embedded prompt) with the SQL query. It then sends this prompt to the Gemini model for optimization and returns the model's response. Handles potential Google API errors (like rate limits or invalid prompts) and returns `None` if optimization fails.
    -   `optimize_all_queries(bucket_name, folder_input, folder_output, sql_files, optimizer)`: Iterates through a list of SQL files in GCS, downloads each query, calls `optimize_sql` for each query using the provided `QueryOptimizer` instance, and uploads the optimized query (Gemini's text response) to GCS as a `.txt` file. Logs success or failure of optimization for each file.

-   **`utils/yaml_loader.py`**:
    -   **`load_yaml(file_path)` Function**:  This module provides a utility function to load YAML configuration files.
    -   It takes a `file_path` as input, reads the YAML file, and parses it into a Python dictionary using `yaml.safe_load`.
    -   Includes error handling for file not found, YAML parsing errors, and value errors (empty file path). It logs information, warnings, errors, and exceptions encountered during the process, returning `None` or an empty dictionary in case of errors, depending on the specific failure.

-   **`utils/file_processor.py`**:
    -   **`FileProcessor` Class**: This module defines the `FileProcessor` class for processing SQL files.
    -   Initialization (`__init__`) takes a configuration (`config`) dictionary, initializes a `Replacer` instance (from `utils.replacer.py`), and sets up logging.
    -   `read_file(file_path)`: Reads lines from a file specified by `file_path`. Includes error handling for `FileNotFoundError` and other exceptions, returning `None` if file reading fails and logging the error.
    -   `write_file(file_path, lines)`: Writes lines to a file at `file_path`. Includes error handling for exceptions, returning `None` in case of failure and logging exceptions.
    -   `process_files(lines, input_file)`: Orchestrates the processing of SQL file lines. It takes a list of `lines` and the `input_file` name, and applies a series of processing steps: removing lines, removing line groups, applying string replacements using `Replacer`, and adding new lines. Logs processing start and completion, handles cases where file reading fails (input lines are `None`), and catches any unexpected exceptions during processing, returning `None` if processing fails and logging exceptions.
    -   `remove_lines(lines)`: Removes lines from the input `lines` that contain any of the substrings specified in the `remove_lines` section of the configuration.
    -   `remove_groups(lines)`: Removes blocks of lines from the input `lines` that are enclosed between start and end markers defined in the `remove_groups` section of the configuration.
    -   `add_new_lines(lines)`: Adds new lines to the input `lines` as specified in the `add_lines` section of the configuration. It inserts new lines at positions defined in the configuration, handling potential `IndexError` if the position is invalid, and logging errors for invalid positions.

-   **`utils/replacer.py`**:
    -   **`Replacer` Class**: Defines the `Replacer` class for performing string replacements in SQL files based on various rules.
    -   Initialization (`__init__`) takes a configuration (`config`) dictionary and sets up logging.
    -   `replace_strings(lines, file_path)`: Orchestrates the string replacement process on a list of `lines`. It takes the lines of a file and the `file_path` as input. It performs global replacements (using `replace_global`), file-specific replacements (using `replace_by_file`), and regex-based replacements (using `replace_by_regex`). Logs the start and completion of replacements for a file, handles `ValueError` for empty input, `pd.errors.EmptyDataError` for empty CSV files in file-specific replacements, and any other unexpected exceptions, returning `None` in case of errors and logging them.
    -   `replace_global(lines)`: Applies global string replacements defined in the `replace_strings_global` section of the configuration to the input `lines`.
    -   `replace_by_file(lines, file_name)`: Applies file-specific string replacements based on rules defined in a CSV file specified in the `replace_strings_by_file` section of the configuration. It reads a CSV, filters rows based on `file_name`, and performs replacements of `source` strings with `target` strings from the CSV rows within the input `lines`.
    -   `replace_by_regex(lines)`: Applies regex-based string replacements defined in the `replace_strings_regex` section of the configuration to the input `lines`. It iterates through regex replacement rules, compiles regex patterns, and uses `re.sub` to perform replacements in each line, handling potential `re.error` for invalid regex patterns and logging errors.



## DAG Workflow

The DAG `bq_translation_workflow` consists of the following tasks, executed in a linear sequence:

1.  **`list_files_preprocessing` (GCSListObjectsOperator)**: Lists files in the specified GCS bucket and input folder (`FOLDER_INPUT`) that will be preprocessed.
2.  **`preprocessing_files` (PythonOperator)**:
    -   Downloads files listed by `list_files_preprocessing` from GCS.
    -   Applies preprocessing steps defined in the YAML configuration file (`PRE_PROCESSING_YAML_PATH`) using the `FileProcessor` utility. These steps may include removing lines, removing groups of lines, and applying string replacements.
    -   Uploads the preprocessed files to the GCS bucket in the preprocessing output folder (`FOLDER_OUTPUT_PRE_PROCESSING`).
3.  **`generate_token` (PythonOperator)**: Generates a Google Cloud access token using default credentials, impersonation or JSON key authentication, based on the `AUTH_METHOD` Airflow Variable. The token is stored in XCom for use by subsequent tasks.
4.  **`execute_bigquery_translation` (PythonOperator)**:
    -   Initiates a BigQuery translation job using the BigQuery Translation API.
    -   Configures the translation job to translate Teradata SQL files located in the preprocessing output folder (`FOLDER_OUTPUT_PRE_PROCESSING`) in GCS to BigQuery SQL, outputting the translated files to the translation output folder (`FOLDER_OUTPUT_TRANSLATION`) in GCS.
    -   Retrieves the access token from XCom.
    -   Pushes the `workflow_id` of the translation job to XCom.
5.  **`check_translation_status` (HttpSensor)**:
    -   Polls the BigQuery Translation API to check the status of the translation job initiated by `execute_bigquery_translation`, using the `workflow_id` from XCom and the access token.
    -   Uses a `HttpSensor` with a custom `response_check` function (`check_translation_status_response`) to determine job success or failure. The sensor retries until the job succeeds, fails, or times out.
6.  **`list_translated_files` (GCSListObjectsOperator)**: Lists the translated SQL files in the translation output folder (`FOLDER_OUTPUT_TRANSLATION/sql/`) in GCS, which are ready for postprocessing and further steps.
7.  **`postprocessing_files` (PythonOperator)**:
    -   Downloads the translated SQL files listed by `list_translated_files` from GCS.
    -   Applies postprocessing steps defined in the YAML configuration file (`POST_PROCESSING_YAML_PATH`) using the `FileProcessor` utility.
    -   Uploads the postprocessed files to the GCS bucket in the postprocessing output folder (`FOLDER_OUTPUT_POST_PROCESSING`).
8.  **`dry_run_queries` (PythonOperator)**:
    -   Performs dry runs of the postprocessed SQL queries located in the translation output folder (`FOLDER_OUTPUT_TRANSLATION/sql/`) in GCS using the `QueryDryRunner` utility.
    -   Logs the dry run results (including execution statistics, errors, and DAG run user information) to a specified BigQuery table (`PROJECT_BQ_LOG.DATASET_BQ_LOG.queries_dry_run_log`).
9.  **`optimize_queries` (PythonOperator)**:
    -   Optionally optimizes the translated SQL queries located in the translation output folder (`FOLDER_OUTPUT_TRANSLATION/sql/`) in GCS using the `QueryOptimizer` utility and Vertex AI's Gemini models. Optimization is performed based on a prompt loaded from GCS (`CONFIG_PROMPT_PATH`).
    -   Uploads the optimized queries to the GCS bucket in the optimized output folder (`FOLDER_OUTPUT_OPTIMIZED`) as text files.
10. **`clear_xcom_task` (PythonOperator)**: Clears all XCom entries associated with the current DAG run to ensure a clean state for future runs. This task is triggered after all other tasks complete, regardless of their success or failure.



## Setup Instructions

### Prerequisites

1.  **Google Cloud Project:** You need a Google Cloud Project with the following APIs enabled:
    -   BigQuery API
    -   BigQuery Migration API
    -   Cloud Storage API
    -   Secret Manager API
    -   Vertex AI API
2.  **Airflow Environment:** You need an Airflow environment, preferably Google Cloud Composer, set up and configured to connect to your Google Cloud Project.
3.  **Python Libraries:** Ensure the following Python libraries are installed in your Airflow environment:
    -   `apache-airflow-providers-google`
    -   `google-cloud-bigquery`
    -   `google-cloud-storage`
    -   `google-cloud-secret-manager`
    -   `google-cloud-vertexai`
    -   `requests`
    -   `PyYAML`
    -   `pandas`
    -   `chardet`
4.  **Service Account Configuration:**
    -   **Translation Service Account (TSA):** Create or use an existing service account dedicated for the translation, dry-run processes and optimization process. This service account needs the following roles:
        -   **BigQuery User**
        -   **Migration Workflow Editor**
        -   **Storage Object Admin**
        -   **Gemini Predict** (Custom role, create it with the `aiplatform.endpoints.predict` permission)
    -   **Composer Service Account:** The service account used by your Cloud Composer environment needs to add the **Service Account Token Creator** role (`roles/iam.serviceAccountTokenCreator`) to be able to impersonate the Translation Service Account if using impersonation authentication.

5. **BigQuery Log Table Setup**

Before running the DAG, ensure you have created the BigQuery table to store dry run logs. Replace `project-name`, `dataset-name` with your actual project and dataset names.

```sql
CREATE OR REPLACE TABLE `project-name.dataset-name.queries_dry_run_log` (
  script_path STRING,
  query STRING,
  log_date TIMESTAMP,
  can_run STRING,
  processing_bytes FLOAT64,
  error_code STRING,
  error_message STRING,
  file_name STRING,
  dag_run_user STRING
);
```

5.1 **Grant BigQuery Data Editor Permission:**

	After creating the queries_dry_run_log table, you need to grant the Translation Service Account (TSA) the BigQuery Data Editor role on this table. This permission is necessary for the TSA to write dry run logs to the table during the DAG execution. You can grant this role using the Google Cloud Console, the bq command-line tool, or programmatically.

6. **Upload Utility Modules and DAG:**

	6.1. Create utils folder: In your Cloud Composer DAGs folder in GCS, create a folder named utils.
	
	6.2. Upload Python Modules: Upload the Python files (dry_run_query.py, query_optimizer.py, yaml_loader.py, file_processor.py, replacer.py) into the utils folder.
	
	6.3. Upload DAG Definition: Upload the DAG file (bq_translation_workflow.py) directly into the DAGs folder.

7. **Configure Airflow Variables:**

	Set up the following Airflow variables in your Airflow environment:
- auth_method: Authentication method to use. Set to 'json' to use a service account key from Secret Manager, 'impersonation' to use service account impersonation or 'default' if you want to use default credentials.
- secret_name: Required if auth_method is json. The name of the Secret Manager secret containing the service account JSON key.
- target_service_account: Required if auth_method is impersonation. The email address of the Translation Service Account to impersonate.

	You can set these variables in the Airflow UI under Admin -> Variables.

8. **GCS Configuration:**

	Ensure you have a GCS bucket configured as specified in the DAG parameters (see "DAG Configuration" below). This bucket should contain:

- **Input SQL files**: In the folder specified by folder_input.
- **Preprocessing Configuration YAML**: At the path specified by pre_processing_yaml_path.
- **Postprocessing Configuration YAML**: At the path specified by post_processing_yaml_path.
- **mapping by file csv**: At the path specified in the replace_strings_by_file.path section of your configuration YAML if using file-specific replacements.
- **YAML files for translation**: To customize the translation process performed by the BigQuery Translation Service, you must place your YAML configuration files in Google Cloud Storage within the output_preprocessing folder.  This folder is specifically designated as the input location from which the BigQuery Translation Service reads and applies your customization configurations during the translation itself.  Example configuration files like remove_setqueryband.config.yaml, timestamp_to_datetime.config.yaml, remove_upper_rtrim.config.yaml, all_uppercase.config.yaml, and optimizer.config.yaml are provided in the config folder of this repository as templates. Ensure you upload your customization YAML files to your GCS bucket, directly into the output_preprocessing folder so that the BigQuery Translation Service can use them.
- **Metadata zip File**: For the BigQuery Translation Service to accurately translate your Teradata SQL, especially schema-related syntax (databases, tables, columns, etc.), you must upload the metadata file produced by the dwh-migration-dumper tool to the output_preprocessing folder in Google Cloud Storage.  This metadata file provides the translator with the necessary context to understand your Teradata schema. Placing it in output_preprocessing ensures the translator can access and utilize this vital schema information during the translation process.
- **Gemini Prompt CSV File**: A CSV file named gemini.prompt containing prompts for Gemini query optimization. You should place this file in a configuration directory within your Cloud Storage bucket, for example, config/prompt_gemini.csv. The path to this file should be specified using the config_prompt_path parameter when running the DAG by config_prompt_path.



## DAG Configuration
The DAG is configured using a combination of:
1. DAG Run Configuration (dag_run.conf): Parameters passed when triggering the DAG manually or via API. These override default values and Airflow Variables.
2. Airflow Variables: Stored in Airflow's metadata database, providing default values and centralized configuration.


## Execution
1. **Trigger the DAG**: You can trigger the DAG manually in the Airflow UI or programmatically via the Airflow API.
2. **Configuration**: When triggering the DAG, you can provide the DAG run configuration (dag_run.conf) as JSON to override the default parameter values. For example:

```
{
  "project_bigquery_log": "bigquery-project where you created the queries_dry_run_log table",
  "dataset_bigquery_log": "bigquery-dataset where you created the queries_dry_run_log table",
  "project_id": "your-gcp-project",
  "location": "your-region",
  "gcs_bucket": "your-gcs-bucket",
  "folder_input": "teradata_sql_input/",
  "folder_output_pre_processing": "preprocessed_sql/",
  "folder_output_translation": "translated_sql/",
  "folder_output_post_processing": "postprocessed_sql/",
  "folder_output_optimized": "optimized_sql/",
  "pre_processing_yaml_path": "config/preprocessing_config.yaml",
  "post_processing_yaml_path": "config/postprocessing_config.yaml",
  "input_extension": ".bteq", 
  "output_extension": ".sql",
  "config_prompt_path": "config/optimization_prompt_config.csv",
  "model_name": "gemini-1.5-pro-001", --update the model when possible
  "username": "your_user_name for logs"
}
```

3. **Monitor DAG Runs**: Monitor the DAG run in the Airflow UI. Check task logs for details on each step of the workflow.
4. **Output**: After successful DAG execution, the translated, postprocessed, and optionally optimized SQL files will be available in the specified GCS output folders. Dry run logs will be stored in the configured BigQuery table.


## Error Handling
The DAG and utility modules are designed with comprehensive error handling.

- AirflowFailException: Critical errors during credential retrieval, file processing, API interactions, or BigQuery operations will raise AirflowFailException, causing the DAG to fail immediately and clearly indicating the failure in Airflow.
- Logging: Detailed logging is implemented throughout the DAG and utility modules, providing insights into the execution flow and potential issues. Check task logs in Airflow UI for detailed error messages and debugging information.
- Retries: Tasks are configured with retries to handle transient errors, especially for GCS operations and API calls.
- Sensors: The HttpSensor for checking translation job status uses mode='reschedule' and poke_interval for efficient polling and resource utilization. It also has a timeout to prevent indefinite waiting.


## YAML Configuration Files (pre and post processing)
The preprocessing and postprocessing steps are driven by YAML configuration files. These files define the rules for removing lines, removing groups of lines, and replacing strings.

Example pre and post processing config yaml:
```
remove_lines:
  - "-- this line should be removed"
remove_groups:
  - start: "/* start of block to remove */"
    end: "/* end of block to remove */"
replace_strings_global:
  - find: "old_string"
    replace: "new_string"
replace_strings_by_file:
  path: "gs://bucket-name/config/replacements.csv"
  fileName: "file_name_column"
  source: "source_column"
  target: "target_column"
replace_strings_regex:
  - pattern: "old_pattern"
    replace: "new_pattern"
add_lines:
  - string: "-- added line at the beginning"
    position: 1
  - string: "-- added line at the end"
```












