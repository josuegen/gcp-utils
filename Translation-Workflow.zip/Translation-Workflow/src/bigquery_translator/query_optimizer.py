import os
import logging
from datetime import datetime, timezone

from typing import List, Any, Dict

import vertexai
from vertexai.generative_models import GenerativeModel, GenerationConfig

from google.cloud import storage
from google.auth.credentials import Credentials
from google.api_core.exceptions import GoogleAPIError
from google.api_core import exceptions as google_exceptions

from bigquery_translator.bigquery_log import BigQueryLogger


logger = logging.getLogger(__name__)


class QueryOptimizer:
    def __init__(
            self,
            project_id: str,
            credentials: Credentials,
            location: str = "us-central1",
            model_name: str = "gemini-2.0-flash-001",
            prompt_path: str = None,
            bucket_name: str = None
    ):
        try:
            if credentials:
                # Initialize with credentials object
                vertexai.init(
                    project=project_id,
                    location=location,
                    credentials=credentials
                )
            else:
                # Default init without credentials
                vertexai.init(
                    project=project_id,
                    location=location
                )
            self.credentials = credentials
            self.model = GenerativeModel(model_name)
            self.prompt_path = prompt_path
            self.bucket_name = bucket_name
            if prompt_path and bucket_name:
                self.prompt = self.load_prompt()

        except GoogleAPIError as e:
            logger.error(f"Error initializing Vertex AI: {e}")
            raise

    def load_prompt(self):
        """Loads the prompt from a file in Google Cloud Storage."""
        try:
            storage_client = storage.Client()
            bucket = storage_client.bucket(self.bucket_name)
            blob = bucket.blob(self.prompt_path)

            return blob.download_as_text()

        except Exception as e:
            logger.exception(
                "An unexpected error occurred "
                f"while loading the prompt from GCS: {e}"
            )
            raise Exception(
                "An unexpected error occurred "
                f"while loading the prompt from GCS: {e}"
            )

    def optimize_sql(self, sql_query):
        prompt_base = self.prompt

        if not prompt_base:
            # If no general prompt is found, use an embedded one
            logger.warning("No prompt found. Using embedded prompt.")
            prompt_base = f"""
            Identify inefficiencies and optimize
            the following SQL query for BigQuery.
            ```sql
            {sql_query}
            ```
            """

        prompt = f"{prompt_base}\n{sql_query}\n```"

        generation_config = GenerationConfig(
            temperature=0.0,
            max_output_tokens=8192
        )
        try:
            result = self.model.generate_content(
                prompt,
                generation_config=generation_config
            )

        except google_exceptions.Forbidden as forbidden_error:
            logger.error(
                "Permission error (403) "
                f"during Gemini query optimization: {forbidden_error}"
            )
            raise Exception(
                "Permission error (403) "
                f"during Gemini query optimization: {forbidden_error}"
            )

        except google_exceptions.GoogleAPIError as e:
            logger.error(f"Error during Gemini query optimization: {e}")
            if e.code == 400:
                logger.error("Check your prompt or model parameters.")
            raise Exception(f"Error during Gemini query optimization: {e}")

        except Exception as e:
            logger.exception(f"An unexpected error occurred: {e}")
            raise Exception(
                "An unexpected error occurred "
                "during Gemini query optimization: {e}"
            )

        return result

    def optimize_all_queries(
            self,
            bucket_name: str,
            folder_output: str,
            sql_files: List[str],
            context: Dict[Any, Any],
            bigquery_log_table: str = None
    ):
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)

        bigquery_logger = BigQueryLogger(
            credentials=self.credentials,
            bigquery_table_id=bigquery_log_table,
            gcs_bucket_name=bucket_name,
            batch_id=context.get("dag_run").run_id,
            step=context.get("task").task_id,
            run_user=self.credentials.signer_email
        )

        for sql_file in sql_files:
            start_ts = datetime.now(timezone.utc)
            error_message = None
            result = "success"

            try:
                blob = bucket.blob(sql_file)
                query = blob.download_as_text()
                optimized_result = self.optimize_sql(sql_query=query)

                if optimized_result:

                    file_name = os.path.basename(sql_file)
                    txt_file_name = os.path.splitext(file_name)[0] + ".txt"
                    txt_file_path = os.path.join(
                        folder_output, txt_file_name
                    )

                    txt_blob = bucket.blob(txt_file_path)
                    txt_blob.upload_from_string(optimized_result.text)

                    logger.info(
                        f"text file generated and uploaded to: {txt_file_path}"
                    )
                else:
                    logger.error(
                        f"Could not optimize query in file: {sql_file}"
                    )

            except Exception as e:
                error_message = e
                result = "fail"
                logger.exception(f"Error processing file {sql_file}: {e}")

            finally:
                bigquery_logger.add_log(
                    start_ts=start_ts,
                    result=result,
                    error_message=error_message,
                    input_script_uri=sql_file,
                    output_script_uri=os.path.join(
                        folder_output, txt_file_name
                    )
                )

        if bigquery_log_table:
            bigquery_logger.persist_logs()
