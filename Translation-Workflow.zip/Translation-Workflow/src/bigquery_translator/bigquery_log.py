import logging
from datetime import datetime, timezone
from typing import Any, Dict

from google.cloud import bigquery
from google.oauth2.service_account import Credentials

logger = logging.getLogger(__name__)


class BigQueryLogger():
    def __init__(
        self,
        credentials: Credentials,
        bigquery_table_id: str,
        gcs_bucket_name: str,
        batch_id: str,
        step: str,
        run_user: str
    ):
        self.bigquery_table_id = bigquery_table_id
        self.bq_client = bigquery.Client(credentials=credentials)
        self.logs = []

        self.gcs_bucket_name = gcs_bucket_name
        self.batch_id = batch_id
        self.step = step
        self.run_user = run_user

    def add_log(
        self,
        start_ts: datetime,
        result: str,
        error_message: str,
        input_script_uri: str,
        output_script_uri: str,
        dry_run: Dict[str, Any] = None,
        end_ts: datetime = datetime.now(timezone.utc),
    ) -> None:
        log = {
            "start_ts": start_ts.strftime('%Y-%m-%d %H:%M:%S.%f UTC'),
            "end_ts": end_ts.strftime('%Y-%m-%d %H:%M:%S.%f UTC'),
            "result": result,
            "error_message": error_message,
            "input_script_uri": input_script_uri,
            "output_script_uri": output_script_uri,
            "dry_run": dry_run,
            "gcs_bucket_name": self.gcs_bucket_name,
            "batch_id": self.batch_id,
            "step": self.step,
            "run_user": self.run_user
        }

        self.logs.append(log)

    def persist_logs(self) -> None:
        try:
            errors = self.bq_client.insert_rows_json(
                table=self.bigquery_table_id,
                json_rows=self.logs
            )
            if errors == []:
                logger.info(f"Step {self.step}: Logs added to BigQuery.")
            else:
                error_message = (
                    f"Encountered errors while inserting "
                    f"step {self.step} logs "
                    f"into BigQuery: {errors}."
                )
                logger.error(error_message)
                raise Exception(error_message)

        except Exception as e:
            error_message = (
                f"Error inserting step {self.step} into BigQuery: {e}."
            )
            logger.exception(error_message)
