import os
import re
import pandas as pd
import logging


class Replacer:
    def __init__(self, config):
        self.config = config
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def replace_strings(self, lines, file_path):
        """
        Replaces strings in lines based on global, file-specific,
        and regex rules.
        """
        try:
            if not lines or not file_path:
                raise ValueError("Lines and file path cannot be empty.")

            file_name = os.path.splitext(os.path.basename(file_path))[0]
            self.logger.info(f"Starting replacements for file: {file_path}")

            lines = self.replace_global(lines)
            lines = self.replace_by_file(lines, file_name)
            lines = self.replace_by_regex(lines)

            self.logger.info(f"Replacements completed for file: {file_path}")
            return lines

        except ValueError as ve:
            self.logger.error(f"Input Error: {ve}")
            return None  # Or raise an exception

        except pd.errors.EmptyDataError as ee:
            # Catch empty CSV files
            self.logger.error(f"Error reading CSV: {ee}")
            return None

        except Exception as e:
            self.logger.exception(f"An unexpected error occurred: {e}")
            return None

    def replace_global(self, lines):
        """Replaces strings based on global rules."""
        global_replacements = self.config.get("replace_strings_global", [])
        for replacement in global_replacements:
            try:
                lines = [
                    line.replace(
                        replacement["find"],
                        replacement["replace"]
                    ) for line in lines]
            except (TypeError, AttributeError) as e:
                # Catch if find/replace are missing
                self.logger.error(
                    f"Error in global replacement: {e}. Skipping replacement."
                )
            except KeyError:
                raise Exception("Find or replacement values not set")

        return lines

    def replace_by_file(self, lines, file_name):
        """Replaces strings based on file-specific rules from a CSV."""
        file_replacements = self.config.get("replace_strings_by_file", {})
        csv_path = file_replacements.get("path")
        if not csv_path:
            return lines

        try:
            df = pd.read_csv(csv_path)
            df = df[df[file_replacements["fileName"]] == file_name]

            if df.empty:  # Add this check
                self.logger.info(
                    f"No matching records found in CSV for file: "
                    f"{file_name}. Skipping file-specific replacements."
                )
                return lines

            for _, row in df.iterrows():
                source = row[file_replacements["source"]]
                target = row[file_replacements["target"]]
                if source == "":  # Check if source is empty
                    self.logger.error(
                        "Error: source argument cannot be empty. "
                        "Skipping replacement."
                    )
                    continue
                lines = [line.replace(source, target) for line in lines]
            return lines

        except (KeyError, TypeError) as e:
            # Handle missing columns or bad config
            self.logger.error(
                f"Error in file-specific replacement configuration: {e}. "
                "Skipping file-specific replacements."
            )
            # Important: return the lines even if the file replacement fails
            return lines

        except FileNotFoundError:
            self.logger.error(
                f"CSV file not found at path: {csv_path}. "
                "Skipping file-specific replacements."
            )
            return lines

    def replace_by_regex(self, lines):
        """
        Replaces strings based on regex rules,
        treating all lines as a single string.
        """

        regex_replacements = self.config.get("replace_strings_regex", [])
        text = "\n".join(lines)  # Combine all lines into a single string
        for replacement in regex_replacements:
            pattern = replacement.get("pattern")
            self.logger.info(f"pattern : {pattern}")
            replacement_text = replacement.get("replace")
            self.logger.info(f"replacement_text : {replacement_text}")
            try:
                if pattern and replacement_text:
                    matches = re.findall(
                        pattern,
                        text,
                        flags=re.IGNORECASE | re.MULTILINE
                    )
                    count_matches = matches
                    self.logger.info(f"Matches found: {count_matches}")
                    text = re.sub(
                        pattern,
                        replacement_text,
                        text,
                        flags=re.IGNORECASE | re.MULTILINE
                    )

            except re.error as e:
                # Handle invalid regex patterns
                self.logger.error(
                    f"Invalid regex pattern: {pattern}. "
                    f"Error: {e}. Skipping regex replacement."
                )
            except (TypeError, AttributeError) as e:
                # Handle missing pattern/replace
                self.logger.error(
                    f"Error in regex replacement: {e}. "
                    "Skipping regex replacement."
                )

        return text.splitlines()
