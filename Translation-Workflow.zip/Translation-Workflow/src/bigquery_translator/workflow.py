"""
   Copyright 2024 Google

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
"""


import os
import logging
import json
import chardet
import requests
from datetime import datetime, timezone

from typing import List, Dict, Any

import google
from google.cloud import storage
from google.cloud import secretmanager
from google.oauth2.service_account import Credentials
from google.auth import impersonated_credentials
from google.auth.transport.requests import Request

from bigquery_translator.file_processor import FileProcessor
from bigquery_translator.query_optimizer import QueryOptimizer
from bigquery_translator.dry_run_query import QueryDryRunner
from bigquery_translator.yaml_loader import load_yaml
from bigquery_translator.bigquery_log import BigQueryLogger

from bigquery_translator.exceptions import (
    TranslationException,
    QueryAdjustmentException,
    OptimizationException,
    AuthenticationException,
    DryRunException
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_credentials(auth_method: str, secret_name: str, target_sa: str):
    """
    Retrieves Google Cloud credentials
    based on the specified authentication method.

    Supports 'impersonation', 'json' and 'default'
    authentication methods.

    Args:
        auth_method (str): Authentication method
            -'impersonation'
            -'json'
            -'default'
        secret_name (str): Secret Manager secret name for 'json' method.
        target_sa (str): Target service account for 'impersonation' method.

    Returns:
        google.auth.credentials.Credentials: Google Cloud credentials object.

    Raises:
        AuthenticationException: If authentication method is invalid
        or credential retrieval fails.
    """
    try:
        if auth_method == "impersonation":
            logger.info(
                "Using impersonation authentication"
                " via google.auth.impersonated_credentials.Credentials."
            )

            if not target_sa:
                raise AuthenticationException(
                    "Target service account (target_sa)"
                    " must be specified for impersonation."
                )

            source_credentials, project_id = google.auth.default(
                scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )

            logger.info(
                f"Type of source_credentials: {type(source_credentials)}"
            )

            target_scopes = ["https://www.googleapis.com/auth/cloud-platform"]
            impersonated_creds = impersonated_credentials.Credentials(
                source_credentials=source_credentials,
                target_principal=target_sa,
                target_scopes=target_scopes,
                lifetime=3600,
            )
            auth_req = google.auth.transport.requests.Request()
            impersonated_creds.refresh(auth_req)
            credentials_obj = impersonated_creds

            logger.info(
                "Successfully created impersonated credentials "
                "using google.auth.impersonated_credentials.Credentials."
            )
            logger.info(
                "Created impersonated credentials object of type: "
                f"{type(credentials_obj)}"
            )

            return credentials_obj

        elif auth_method == "json":
            logger.info("Using JSON key authentication.")
            if not secret_name:
                raise AuthenticationException(
                    "Secret name cannot be empty for JSON authentication."
                )
            credentials_json = get_secret_value(secret_name)
            credentials_info = json.loads(credentials_json)
            credentials = Credentials.from_service_account_info(
                    info=credentials_info,
                    scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )

            return credentials

        elif auth_method == "default" or not auth_method:
            logger.info("Using default authentication.")
            credentials, project = google.auth.default(
                scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )
            if not credentials.valid:
                credentials.refresh(Request())
            return credentials

        else:
            raise AuthenticationException(
                f"Invalid authentication method: {auth_method}."
                "Must be 'json', 'impersonation' or 'default'."
            )

    except ValueError as ve:
        logger.error(f"Input Error in get_credentials: {ve}")
        raise AuthenticationException(f"Input Error in get_credentials: {ve}")

    except json.JSONDecodeError as jde:
        logger.error(f"Invalid JSON credentials in get_credentials: {jde}")
        raise AuthenticationException(
            f"Invalid JSON credentials in get_credentials: {jde}"
        )

    except Exception as e:
        logger.exception(
            "Unexpected error during credential retrieval "
            "using google.auth.impersonated_credentials.Credentials: {e}"
        )
        raise AuthenticationException(
            f"Unexpected error during credential retrieval: {e}"
        )


def get_secret_value(secret_name: str) -> str:
    """
    Retrieves a secret value from Google Cloud Secret Manager.

    Args:
        secret_name (str): The name of the Secret Manager secret.

    Returns:
        str: The secret value.

    Raises:
        AuthenticationException:
        If secret retrieval fails due to input error or other exceptions.
    """
    try:
        if not secret_name:
            raise ValueError("Secret name cannot be empty.")

        client = secretmanager.SecretManagerServiceClient()
        response = client.access_secret_version(request={"name": secret_name})
        secret_value = response.payload.data.decode("UTF-8")

    except ValueError as ve:
        logger.error(f"Input Error in get_secret_value: {ve}")
        raise AuthenticationException(f"Input Error in get_secret_value: {ve}")

    except Exception as e:
        logger.exception(f"Unexpected error while accessing secret: {e}")
        raise AuthenticationException(
            f"Unexpected error in get_secret_value: {e}"
        )

    return secret_value


def generate_access_token(
    auth_method: str,
    secret_name: str,
    target_sa: str,
    **kwargs
) -> str:
    """
    Generates a Google Cloud access token,
    using the specified authentication method.

    Pushes the generated access token to XCom for use by downstream tasks.

    Args:
        auth_method (str): Authentication method ('impersonation' or 'json').
        secret_name (str): Secret Manager secret name (for 'json' method).
        target_sa (str): Target service account for impersonation.
        **kwargs: Airflow context dictionary.

    Raises:
        AuthenticationException: If access token generation fails.
    """
    try:
        logger.info(f"Generating access token using: {auth_method} method")

        credentials = get_credentials(auth_method, secret_name, target_sa)

        auth_req = google.auth.transport.requests.Request()
        credentials.refresh(auth_req)
        token = credentials.token

        logger.info("Access token generated successfully.")

        return token

    except ValueError as ve:
        logger.error(f"Input Error in generate_access_token: {ve}")
        raise AuthenticationException(
            f"Input Error in generate_access_token: {ve}"
        )

    except Exception as e:
        logger.exception(
            f"Unexpected error during access token generation: {e}"
        )
        raise AuthenticationException(
            f"Unexpected error during access token generation: {e}"
        )


def read_gcs_file_with_chardet(bucket_name: str, blob_name: str) -> List[str]:
    """
    Reads a file from Google Cloud Storage, detects encoding using chardet,
    and returns lines as a list.

    Args:
        bucket_name (str): Name of the GCS bucket.
        blob_name (str): Name of the blob (file) in the bucket.

    Returns:
        list: Lines of the file as a list of strings.

    Raises:
        Exception: If file reading, encoding detection, or decoding fails.
    """
    try:
        if not bucket_name or not blob_name:
            raise TranslationException(
                "Bucket name and blob name cannot be empty."
            )

        logger.info(f"Reading file: gs://{bucket_name}/{blob_name}")

        client = storage.Client()
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(blob_name)

        raw_data = blob.download_as_bytes()

        result = chardet.detect(raw_data)
        encoding = result["encoding"]

        if not encoding:
            raise TranslationException("Could not detect file encoding.")

        logger.info(f"Detected encoding: {encoding}")

        decoded_data = raw_data.decode(encoding)
        lines = decoded_data.splitlines()

        logger.info(f"File read successfully. Number of lines: {len(lines)}")
        return lines

    except ValueError as ve:
        logger.error(f"Input Error in read_gcs_file_with_chardet: {ve}")
        raise QueryAdjustmentException(
            f"Input Error in read_gcs_file_with_chardet: {ve}"
        )

    except UnicodeDecodeError as ude:
        logger.error(
            f"Decoding error in read_gcs_file_with_chardet: {ude}."
            " Detected encoding was {encoding}."
        )
        raise QueryAdjustmentException(
            "Unicode decoding error for file "
            f"gs://{bucket_name}/{blob_name} with encoding {encoding}: {ude}"
        )

    except Exception as e:
        logger.exception(f"Unexpected error during file reading: {e}")
        raise QueryAdjustmentException(
            "Unexpected error while reading file "
            F"gs://{bucket_name}/{blob_name}: {e}"
        )


def process_files_from_gcs(
    bucket_name: str,
    config_file_blob_name: str,
    input_prefix: str,
    output_prefix: str,
    input_files_list: List[str],
    output_extension: str = ".sql",
    input_extension: str = ".bteq",
    auth_method: str = "default",
    secret_name: str = None,
    target_sa: str = None,
    **kwargs
) -> None:
    """
    Processes files from GCS without downloading them locally,
    using google-cloud-storage.

    Args:
        bucket_name (str): GCS bucket name.
        config_path (str): Path to the configuration YAML file in GCS.
        folder_input (str): GCS folder for input files.
        folder_output (str): GCS folder for output files.
        output_extension (str): Extension for output files.
        input_extension (str): Extension of input files to process.
        input_files_list (str): List of files to process
        auth_method (str): Authentication method ('json' or 'impersonation').
        secret_name (str): Secret Manager secret name for service account key.
        target_sa (str): Target service account for impersonation.
        **context: Airflow context dictionary.

    Raises:
        QueryAdjustmentException:
            If input is invalid or any step of file processing fails.
    """
    try:
        if not input_files_list:
            raise QueryAdjustmentException("Empty input files list passed")

        filtered_input_files = [
            file for file in input_files_list if file.endswith(input_extension)
        ]

        if not filtered_input_files:
            raise QueryAdjustmentException(
                "No valid input files found for processing"
            )

        logger.info(
            f"Found {len(filtered_input_files)} files to process"
            f" in bucket {bucket_name}, folder {input_prefix}"
        )

        # Get credentials
        credentials = get_credentials(auth_method, secret_name, target_sa)

        if credentials is None:
            raise QueryAdjustmentException("Failed to retrieve credentials")

        storage_client = storage.Client(credentials=credentials)
        bucket_obj = storage_client.bucket(bucket_name=bucket_name)

        # Download configuration file directly to memory
        config_blob = bucket_obj.blob(blob_name=config_file_blob_name)
        config_content = config_blob.download_as_string()
        config = load_yaml(yaml_content=config_content)
        processor = FileProcessor(config=config)

        for input_file in filtered_input_files:
            logger.info(f"Processing file: {input_file}")
            # Use read_gcs_file_with_chardet with bucket_name and blob_name
            lines = read_gcs_file_with_chardet(bucket_name, input_file)

            if lines is None:  # Handle file read errors.
                logger.error(f"Failed to read input file: {input_file}.")
                logger.warning(f"Skipping {input_file}")
                continue  # Go to the next file

            processed_lines = processor.process_files(lines, input_file)

            output_file_name = (
                os.path.splitext(os.path.basename(input_file))[0]
                + output_extension
            )
            output_gcs_path = os.path.join(output_prefix, output_file_name)
            output_blob = bucket_obj.blob(blob_name=output_gcs_path)

            # Upload processed file directly to GCS
            output_content = "\n".join(processed_lines).encode("utf-8")
            output_blob.upload_from_string(data=output_content)

            logger.info(
                f"Uploaded processed file: {output_gcs_path}."
            )

        logger.info("File processing completed successfully.")

    except ValueError as ve:
        logger.error(f"Input Error in process_files_from_gcs: {ve}")
        raise QueryAdjustmentException(
            f"Input Error in process_files_from_gcs: {ve}"
        )

    except Exception as e:
        logger.exception(f"Unexpected error in process_files_from_gcs: {e}")
        raise QueryAdjustmentException(
            f"Unexpected error in process_files_from_gcs: {e}"
        )


def process_files_from_gcs_airflow(
    bucket_name: str,
    config_file_blob_name: str,
    input_prefix: str,
    output_prefix: str,
    input_files_list: List[str],
    credentials: Credentials,
    context: Dict[Any, Any],
    bigquery_log_table: str = None,
    output_extension: str = ".sql",
    input_extension: str = ".bteq",
    **kwargs
) -> None:
    """
    Processes files from GCS without downloading them locally,
    using google-cloud-storage.

    Args:
        bucket_name (str): GCS bucket name.
        config_path (str): Path to the configuration YAML file in GCS.
        folder_input (str): GCS folder for input files.
        folder_output (str): GCS folder for output files.
        output_extension (str): Extension for output files.
        input_extension (str): Extension of input files to process.
        input_files_list (str): List of files to process
        auth_method (str): Authentication method ('json' or 'impersonation').
        secret_name (str): Secret Manager secret name for service account key.
        target_sa (str): Target service account for impersonation.
        **context: Airflow context dictionary.

    Raises:
        QueryAdjustmentException:
            If input is invalid or any step of file processing fails.
    """
    try:
        if not input_files_list:
            raise QueryAdjustmentException("Empty input files list passed")

        filtered_input_files = [
            file for file in input_files_list if file.endswith(input_extension)
        ]

        if not filtered_input_files:
            raise QueryAdjustmentException(
                "No valid input files found for processing"
            )

        logger.info(
            f"Found {len(filtered_input_files)} files to process"
            f" in bucket {bucket_name}, folder {input_prefix}"
        )

        if credentials is None:
            raise QueryAdjustmentException("Failed to retrieve credentials")

        storage_client = storage.Client(credentials=credentials)
        bucket_obj = storage_client.bucket(bucket_name=bucket_name)

        # Download configuration file directly to memory
        config_blob = bucket_obj.blob(blob_name=config_file_blob_name)
        config_content = config_blob.download_as_string()
        config = load_yaml(yaml_content=config_content)
        processor = FileProcessor(config=config)

        # BigQuery log table
        bigquery_logger = BigQueryLogger(
            bigquery_table_id=bigquery_log_table,
            gcs_bucket_name=bucket_name,
            batch_id=context.get("dag_run").run_id,
            step=context.get("task").task_id,
            credentials=credentials,
            run_user=credentials.signer_email
        )

        for input_file in filtered_input_files:
            logger.info(f"Processing file: {input_file}")
            start_ts = datetime.now(timezone.utc)
            error_message = None
            result = "success"

            try:
                # Use read_gcs_file_with_chardet with bucket_name and blob_name
                lines = read_gcs_file_with_chardet(bucket_name, input_file)

                if lines is None:  # Handle file read errors.
                    logger.error(f"Failed to read input file: {input_file}.")
                    logger.warning(f"Skipping {input_file}")
                    continue  # Go to the next file

                processed_lines = processor.process_files(lines, input_file)

                output_file_name = (
                    os.path.splitext(os.path.basename(input_file))[0]
                    + output_extension
                )
                output_gcs_path = os.path.join(output_prefix, output_file_name)
                output_blob = bucket_obj.blob(blob_name=output_gcs_path)

                # Upload processed file directly to GCS
                output_content = "\n".join(processed_lines).encode("utf-8")
                output_blob.upload_from_string(data=output_content)

                logger.info(
                    f"Uploaded processed file: {output_gcs_path}."
                )
            except Exception as e:
                error_message = e
                result = "fail"
                logger.error(f"Error procesing file: {input_file}")

            finally:
                bigquery_logger.add_log(
                    start_ts=start_ts,
                    result=result,
                    error_message=error_message,
                    input_script_uri=input_file,
                    output_script_uri=output_blob.name
                )

        logger.info(f"File processing completed {result}.")
        bigquery_logger.persist_logs()

    except ValueError as ve:
        logger.error(f"Input Error in process_files_from_gcs: {ve}")
        raise QueryAdjustmentException(
            f"Input Error in process_files_from_gcs: {ve}"
        )

    except Exception as e:
        logger.exception(f"Unexpected error in process_files_from_gcs: {e}")
        raise QueryAdjustmentException(
            f"Unexpected error in process_files_from_gcs: {e}"
        )


def optimize_queries(
    project_id: str,
    location: str,
    bucket: str,
    output_prefix: str,
    input_files_list: List[str],
    model_name: str,
    auth_method: str = "default",
    secret_name: str = None,
    target_sa: str = None,
    config_prompt_path: str = None,
    **kwargs,
) -> None:
    """
    Method to optimize queries using a specified authentication method.

    Retrieves credentials based on the configured
    authentication method, initializes QueryOptimizer, and optimizes queries
    in the input files.

    Raises:
        Exception:
            If there are input errors or unexpected exceptions.
    """
    try:

        if not input_files_list:
            raise OptimizationException("No input files passed")

        credentials = get_credentials(auth_method, secret_name, target_sa)
        if credentials is None:
            raise OptimizationException("Failed to retrieve credentials.")

        optimizer = QueryOptimizer(
            project_id,
            location,
            model_name=model_name,
            credentials=credentials,
            prompt_path=config_prompt_path,
            bucket_name=bucket,
        )

        optimizer.optimize_all_queries(
            bucket_name=bucket,
            folder_output=output_prefix,
            sql_files=input_files_list,
            optimizer=optimizer
        )

    except ValueError as ve:
        logger.error(f"Input Error in optimize_queries_task: {ve}")
        raise OptimizationException(
            f"Input Error in optimize_queries_task: {ve}"
        )

    except Exception as e:
        logger.exception(f"Unexpected error in optimize_queries_task: {e}")
        raise OptimizationException(
            f"Unexpected error in optimize_queries_task: {e}"
        )


def optimize_queries_airflow(
    project_id: str,
    location: str,
    bucket: str,
    output_prefix: str,
    input_files_list: List[str],
    model_name: str,
    context: Dict[Any, Any],
    credentials: Credentials,
    config_prompt_path: str = None,
    bigquery_log_table: str = None,
    **kwargs,
) -> None:
    """
    Method to optimize queries using a specified authentication method.

    Retrieves credentials based on the configured
    authentication method, initializes QueryOptimizer, and optimizes queries
    in the input files.

    Raises:
        Exception:
            If there are input errors or unexpected exceptions.
    """
    try:

        if not input_files_list:
            raise OptimizationException("No input files passed")

        optimizer = QueryOptimizer(
            project_id=project_id,
            location=location,
            model_name=model_name,
            prompt_path=config_prompt_path,
            bucket_name=bucket,
            credentials=credentials
        )

        optimizer.optimize_all_queries(
            bucket_name=bucket,
            folder_output=output_prefix,
            sql_files=input_files_list,
            context=context,
            bigquery_log_table=bigquery_log_table
        )

    except ValueError as ve:
        logger.error(f"Input Error in optimize_queries_task: {ve}")
        raise OptimizationException(
            f"Input Error in optimize_queries_task: {ve}"
        )

    except Exception as e:
        logger.exception(f"Unexpected error in optimize_queries_task: {e}")
        raise OptimizationException(
            f"Unexpected error in optimize_queries_task: {e}"
        )


def execute_bigquery_translation(
    project_id: str,
    location: str,
    input_prefix: str,
    output_prefix: str,
    gcs_bucket: str,
    access_token: str,
    **kwargs
) -> str:
    """
    Executes a BigQuery Teradata to BigQuery translation job,
    using the Translation API.

    Args:
        project_id (str): Google Cloud project ID.
        location (str): Google Cloud location.
        folder_input (str): GCS folder path for input files.
        folder_output (str): GCS folder path for output files.
        gcs_bucket (str): GCS bucket name.
        access_token (str): Google Cloud access token.
        **kwargs: Airflow context dictionary.

    Returns:
        str: Workflow ID of the translation job.

    Raises:
        TranslationException:
            If there are errors starting the translation job
            or parsing the response.
    """
    path_input = f"gs://{gcs_bucket}/{input_prefix}"
    path_output = f"gs://{gcs_bucket}/{output_prefix}"

    json_body = {
        "tasks": {
            "Teradata2BigQuery": {
                "type": "Teradata2BigQuery_Translation",
                "translation_details": {
                    "target_base_uri": path_output,
                    "source_target_mapping": {
                        "source_spec": {"base_uri": path_input}
                    },
                },
            }
        }
    }

    url = "/". join(
        [
            "https://bigquerymigration.googleapis.com",
            "v2alpha",
            "projects",
            project_id,
            "locations",
            location,
            "workflows"
        ]
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}",
    }

    try:
        response = requests.post(
            url=url,
            headers=headers,
            data=json.dumps(json_body)
        )

        # Raise HTTPError for bad responses (4xx or 5xx)
        response.raise_for_status()
        logger.info(
            "Translation job started."
            f"Status Code: {response.status_code}"
        )

        workflow_id = response.json().get("name").split("/")[-1]
        logger.info(f"Translation job executed. Workflow ID: {workflow_id}")

    except requests.exceptions.RequestException as e:
        logger.error(f"Error starting translation job: {e}")
        raise TranslationException(
            f"Error starting translation job: {e}"
        )

    except (KeyError, AttributeError) as e:
        # Handle potential JSON parsing errors
        response_text = response.text if "response" in locals() else "N/A"
        logger.error(
            f"Error parsing response JSON: {e}. "
            f"Response text: {response_text}"
        )
        raise TranslationException(
            f"Error parsing response JSON: {e}"
        )

    except Exception as e:  # Catch any other unexpected error
        logger.exception(f"Unexpected error: {e}")
        raise TranslationException(
            f"Unexpected error: {e}"
        )

    return workflow_id


def poke_translation_status(
        project_id: str,
        location: str,
        translation_job_id: str,
        access_token: str
) -> requests.Response:

    url = "/". join(
        [
            "https://bigquerymigration.googleapis.com",
            "v2alpha",
            "projects",
            project_id,
            "locations",
            location,
            "workflows",
            translation_job_id
        ]
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}",
    }

    try:
        response = requests.get(
            url=url,
            headers=headers
        )

        # Raise HTTPError for bad responses (4xx or 5xx)
        response.raise_for_status()

        return response

    except requests.exceptions.RequestException as e:
        logger.error(f"Error poking for translation job: {e}")
        raise TranslationException(
            f"Error poking for translation job: {e}"
        )

    except Exception as e:  # Catch any other unexpected error
        logger.exception(f"Unexpected error: {e}")
        raise TranslationException(
            f"Unexpected error: {e}"
        )


def check_translation_status_response(response: requests.Response) -> bool:
    """
    Checks the HTTP response from the BigQuery Translation API for job status.

    Args:
        response (requests.Response):
            HTTP response object from the Translation API.

    Returns:
        bool: True if the translation job succeeded,
            False otherwise (for retry).

    Raises:
        TranslationException: If the translation job failed or was cancelled.
    """
    try:
        # Raise HTTPError for bad responses (4xx or 5xx)
        response.raise_for_status()
        data = response.json()
        state = data.get("tasks", {}).get("Teradata2BigQuery", {}).get("state")

        if state == "SUCCEEDED":
            logger.info(f"Translation job completed successfully: {state}")

            return True  # Success!

        elif state == "RUNNING":
            logger.info(
                "Translation job is still running. "
                "Checking again later."
            )

        elif state == "FAILED":
            error_message = (
                data.get("tasks", {})
                .get("Teradata2BigQuery", {})
                .get("processingError", {})
                .get("reason")
            )  # Extract error message

            logger.error(f"Translation job failed: {error_message}")
            raise TranslationException(
                f"Translation job failed: {error_message}"
            )

        elif state == "CANCELLED":
            logger.warning("Translation job was cancelled.")
            raise TranslationException("Translation job was cancelled.")

        else:  # Handle other states or unexpected responses
            logger.warning(
                f"Unexpected translation job state: {state}. Response: {data}"
            )
            raise TranslationException(
                f"Unexpected translation job state: {state}. Response: {data}"
            )

    except requests.exceptions.RequestException as e:  # Catch HTTP errors
        logger.error(f"Error checking translation status: {e}")
        raise TranslationException(
           f"Error checking translation status: {e}"
        )

    except (KeyError, TypeError) as e:  # Handle missing keys in JSON response
        logger.error(
            f"Error parsing translation status response: {e}. "
            f"Response: {response.text}"
        )
        raise TranslationException(
            f"Error parsing translation status response: {e}. "
            f"Response: {response.text}"
        )

    except Exception as e:
        logger.error(
            f"Unexpected error while checking translation status: {e}"
        )
        raise TranslationException(
            f"Error parsing translation status response: {e}. "
            f"Response: {response.text}"
        )

    return False


def dry_run_task(
    bucket: str,
    input_prefix: str,
    dry_run_log_table: str,
    input_file_list: List[str],
    input_extension: str,
    secret_name: str,
    target_sa: str,
    auth_method: str = "default",
    username: str = "default",
    **kwargs,
):
    """
    Airflow task to execute dry runs for SQL queries in GCS files
    and log results to BigQuery.

    Retrieves input files from XCom, initializes QueryDryRunner with provided
    credentials, and executes dry runs for all SQL queries.

    Args:
        bucket (str): GCS bucket name.
        input_prefix (str): GCS folder path containing SQL input files.
        dry_run_log_table (str): BigQuery table for logging dry run results
            (project.dataset.table).
        input_file_list (str): List of files to process
        input_extension (str): Extension of input SQL files.
        auth_method (str): Authentication method ('json' or 'impersonation').
        secret_name (str): Secret Manager secret name for service account key.
        target_sa (str): Target service account for impersonation.
        username (str): Username to record in dry run logs.
        **context: Airflow context dictionary.

    Raises:
        DryRunException: If input is invalid or dry run execution fails.
    """
    logger.info(
        f"Starting dry_run_task with bucket: {bucket}, "
        f"input_prefix: {input_prefix}, "
        f"dry_run_log_table: {dry_run_log_table}"
    )

    try:
        filtered_input_files = [
            file for file in input_file_list if file.endswith(input_extension)
        ]

        credentials = get_credentials(auth_method, secret_name, target_sa)
        if credentials is None:
            raise DryRunException(
                "Failed to retrieve credentials for Dry Run Task."
            )

        dry_runner = QueryDryRunner(credentials=credentials)
        dry_runner.dry_run_all_queries(
            bucket_name=bucket,
            folder_path=input_prefix,
            sql_files=filtered_input_files,
            dry_run_log_table=dry_run_log_table,
            dag_run_user=username
        )

    except ValueError as ve:
        logger.error(f"Input Error in dry_run_task: {ve}")
        raise DryRunException(f"Input Error in dry_run_task: {ve}")

    except Exception as e:
        logger.exception(f"Unexpected error in dry_run_task: {e}")
        raise DryRunException(f"Unexpected error in dry_run_task: {e}")


def dry_run_task_airflow(
    bucket: str,
    input_prefix: str,
    bigquery_log_table_id: str,
    input_file_list: List[str],
    input_extension: str,
    credentials: Credentials,
    context: Dict[Any, Any],
    username: str = "default",
    **kwargs,
):
    """
    Airflow task to execute dry runs for SQL queries in GCS files
    and log results to BigQuery.

    Retrieves input files from XCom, initializes QueryDryRunner with provided
    credentials, and executes dry runs for all SQL queries.

    Args:
        bucket (str): GCS bucket name.
        input_prefix (str): GCS folder path containing SQL input files.
        bigquery_log_table_id (str): BigQuery table for logging dry run results
            (project.dataset.table).
        input_file_list (str): List of files to process
        input_extension (str): Extension of input SQL files.
        auth_method (str): Authentication method ('json' or 'impersonation').
        secret_name (str): Secret Manager secret name for service account key.
        target_sa (str): Target service account for impersonation.
        username (str): Username to record in dry run logs.
        **context: Airflow context dictionary.

    Raises:
        DryRunException: If input is invalid or dry run execution fails.
    """
    logger.info(
        f"Starting dry_run_task with bucket: {bucket}, "
        f"input_prefix: {input_prefix}, "
        f"dry_run_log_table: {bigquery_log_table_id}"
    )

    try:
        filtered_input_files = [
            file for file in input_file_list if file.endswith(input_extension)
        ]

        if credentials is None:
            raise DryRunException(
                "Failed to retrieve credentials for Dry Run Task."
            )

        dry_runner = QueryDryRunner(credentials=credentials)
        dry_runner.dry_run_all_queries(
            bucket_name=bucket,
            sql_files=filtered_input_files,
            dry_run_log_table_name=bigquery_log_table_id,
            context=context,
            credentials=credentials
        )

    except ValueError as ve:
        logger.error(f"Input Error in dry_run_task: {ve}")
        raise DryRunException(f"Input Error in dry_run_task: {ve}")

    except Exception as e:
        logger.exception(f"Unexpected error in dry_run_task: {e}")
        raise DryRunException(f"Unexpected error in dry_run_task: {e}")