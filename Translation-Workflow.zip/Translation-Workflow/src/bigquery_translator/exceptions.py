class TranslationException(Exception):
    pass


class QueryAdjustmentException(Exception):
    pass


class OptimizationException(Exception):
    pass


class AuthenticationException(Exception):
    pass


class DryRunException(Exception):
    pass
