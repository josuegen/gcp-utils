import logging
from datetime import datetime, timezone

from typing import Dict, Any, List

from google.cloud import storage
from google.cloud import bigquery
from google.api_core.exceptions import GoogleAPIError
from google.oauth2.service_account import Credentials

from bigquery_translator.bigquery_log import BigQueryLogger

logger = logging.getLogger(__name__)


class QueryDryRunner:
    def __init__(self, credentials=None):
        """
        Initializes QueryDryRunner with optional credentials.
        If credentials are not provided, default credentials will be used.
        """
        self.credentials = credentials

    def dry_run_query(
            self,
            bucket_name: str,
            sql_file_name: str
    ) -> Dict[str, Any]:
        """
        Performs a dry run of a SQL query and returns metadata,
        including the DAG run user.
        """
        # Logging info
        metadata = {}
        start_ts = datetime.now(timezone.utc)
        able_to_run = False
        bytes_processed = None
        error_code = None
        error_message = ""
        result = "success"

        storage_client = storage.Client(credentials=self.credentials)
        bucket = storage_client.bucket(bucket_name=bucket_name)
        blob = bucket.blob(blob_name=sql_file_name)

        try:
            query = blob.download_as_text()
        except Exception as e:
            logger.error(f"Error downloading file {sql_file_name}: {e}")

        client = bigquery.Client(credentials=self.credentials)
        job_config = bigquery.QueryJobConfig(
            dry_run=True,
            use_query_cache=False
        )

        try:
            query_job = client.query(query, job_config=job_config)
            bytes_processed = query_job.total_bytes_processed

        except GoogleAPIError as e:
            error_code = e.code
            error_message = str(e)
            result = "fail"

        except Exception as e:
            logger.exception(
                f"An unexpected error occurred during dry run: {e}"
            )
            error_message = f"An unexpected error occurred during dry run: {e}"
            result = "fail"

        finally:
            metadata = {
                "input_script_uri": sql_file_name,
                "output_script_uri": sql_file_name,  # No transformations made
                "start_ts": start_ts,
                "dry_run": {
                    "able_to_run": able_to_run,
                    "processing_bytes": bytes_processed
                },
                "error_message": f"{error_code}: {error_message}",
                "result": result
            }

        return metadata

    def dry_run_all_queries(
            self,
            bucket_name: str,
            sql_files: List[str],
            dry_run_log_table_name: str,
            credentials: Credentials,
            context: Dict[Any, Any]
    ):
        """
        Performs dry runs for all provided SQL files and logs the results,
        including DAG run user.
        """

        # BigQuery log table
        bigquery_logger = BigQueryLogger(
            credentials=credentials,
            bigquery_table_id=dry_run_log_table_name,
            gcs_bucket_name=bucket_name,
            batch_id=context.get("dag_run").run_id,
            step=context.get("task").task_id,
            run_user=self.credentials.service_account_email
        )

        for sql_file in sql_files:
            metadata = self.dry_run_query(
                bucket_name=bucket_name,
                sql_file_name=sql_file
            )

            bigquery_logger.add_log(**metadata)

        bigquery_logger.persist_logs()
