import logging
from bigquery_translator.replacer import Replacer


class FileProcessor:
    def __init__(self, config):
        self.config = config
        self.replacer = Replacer(config)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def read_file(self, file_path):
        """Reads lines from a file."""
        try:
            with open(file_path, 'r', encoding="utf-8") as file:
                return file.readlines()
        except FileNotFoundError:
            self.logger.error(f"File not found: {file_path}")
            return None
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred: {e}")
            return None

    def write_file(self, file_path, lines):
        """Writes lines to a file."""
        try:
            with open(file_path, 'w', encoding="utf-8") as file:
                file.writelines(lines)
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred: {e}")
            return None

    def process_files(self, lines, input_file):
        """Processes lines by removing, replacing, and adding."""
        try:
            if lines is None:  # Handle if file reading failed
                self.logger.error(
                    f"No lines to process for file: {input_file}"
                )
                return None

            self.logger.info(f"Processing file: {input_file}")

            lines = self.remove_lines(lines)
            lines = self.remove_groups(lines)
            lines = self.replacer.replace_strings(lines, input_file)
            lines = self.add_new_lines(lines)

            self.logger.info(f"File processing complete for: {input_file}")
            return lines
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred: {e}")
            return None

    def remove_lines(self, lines):
        """Removes lines containing specified substrings."""
        to_remove = self.config.get("remove_lines", [])
        return [
            line for line in lines if not any(
                substring.lower() in line.lower() for substring in to_remove
            )
        ]

    def remove_groups(self, lines):
        """Removes groups of lines enclosed by start and end markers."""
        groups = self.config.get("remove_groups", [])
        result = []
        skip = False

        for line in lines:
            if any(group["start"].lower() in line.lower() for group in groups):
                skip = True
            if not skip:
                result.append(line)
            if any(group["end"].lower() in line.lower() for group in groups):
                skip = False
        return result

    def add_new_lines(self, lines):
        """Adds new lines at specified positions."""
        to_add = self.config.get("add_lines", [])
        for item in to_add:
            string = item["string"]
            position = item.get("position", len(lines))
            try:  # Handle invalid positions
                lines.insert(position - 1, string + "\n")
            except IndexError:
                self.logger.error(
                    f"Invalid position {position} for adding line: {string}"
                )
        return lines
