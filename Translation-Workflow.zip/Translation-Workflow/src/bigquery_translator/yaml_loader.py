import yaml
import logging

logger = logging.getLogger(__name__)


def load_yaml(yaml_content):
    """Loads YAML data from a string with error handling and logging."""

    try:
        if not yaml_content:
            raise ValueError("YAML content cannot be empty.")

        logger.info("Loading YAML from string content.")

        data = yaml.safe_load(yaml_content)

        if data is None:  # Check for empty YAML content
            logger.warning("YAML content is empty or contains no valid YAML.")
            return {}  # Return an empty dictionary or raise an exception

        logger.info("YAML loaded successfully from string content.")
        return data

    except yaml.YAMLError as e:  # Catch YAML parsing errors
        logger.error(f"YAML parsing error: {e}")
        return None  # Or raise an exception

    except ValueError as ve:
        logger.error(f"Input Error: {ve}")
        return None

    except Exception as e:
        logger.exception(f"An unexpected error occurred: {e}")
        return None  # Or raise an exception
