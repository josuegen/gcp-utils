# Project Configuration

This project relies on several configuration files that are essential for its proper functioning. Below is a description of the different types of files and how they should be handled.


## Required Configuration Files (Non-Modifiable)

These files are required for the project to execute successfully. If they are not present, the process will fail. Modification of these configuration files is not recommended, as it may lead to unexpected results.

* `gemini.prompt`: prompt used to optimize translated queries.
    * Modifying this file can cause instability on gemini predictions.
    * The file path must be specified via the config_prompt_path variable when executing the process.


## Optional Configuration Files (Modifiable)

These configuration files are optional and are only required if pre- or post-translation SQL file transformations are necessary. If such transformations are not needed, these files can be omitted.

* `pre_processing.yaml`: Contains the configuration to transform the sql files before the translation.
    * Ensure that you review and modify the default values to match your needs.
    * Refer to the `config.pre_processing.yaml` file for a template and examples of available parameters.
    * The file path must be specified via the pre_processing_yaml_path variable when executing the process.
* `post_processing.yaml`: Contains the configuration to transform the sql files after the translation.
    * Ensure that you review and modify the default values to match your needs.
    * Refer to the `config.post_processing.yaml` file for a template and examples of available parameters.
    * The file path must be specified via the post_processing_yaml_path variable when executing the process.
* `replacements_by_file.csv`: Provides file-level mapping for variable substitution, facilitating context-sensitive replacements across multiple SQL files. This mechanism is crucial for pre-processing SQL files prior to translation with metadata, ensuring accurate identification of database objects (e.g., tables, columns) when a single variable represents differing values across files. For instance, it allows the dynamic replacement of a database name variable with its concrete value, enabling precise metadata-driven translation.
    * you must specify at least 3 columns: the file name, source value, target value.
    * If file-level string replacements are required, specify the file path and column mappings within the replace_strings_by_file section of pre_processing.yaml or post_processing.yaml depending on your needs.


## Optional Configuration Files (Non-Modifiable)

hese files provide examples of optional configurations that allow you to customize the output of the BigQuery translation. They are used by the translator, but their absence will not cause the process to fail.

* `optimizer.config.yaml`: this configuration is used to optimize and improve the performance of translated SQL.
    * It is recommended not to modify this file unless you fully understand the implications of the changes.
* `all_uppercase.config.yaml`: converts to uppercase object names and Keywords.
* `remove_setqueryband.config.yaml`: Suppresses additional output code for source SET QUERY_BAND and COLLECT STATS statements.
* `remove_upper_rtrim.config.yaml`: Disables RTRIM and UPPER on join comparisons. Use this configuration only when you are certain that data in the comparison columns is case-insensitive, or when you intend to modify the data to ensure case-insensitivity. Otherwise, the join may produce unexpected results due to mismatches.
* `timestamp_to_datetime.config.yaml`: converts a TIMESTAMP data type to DATETIME.

    * Configuration of these files is subject to Google updates; validate against official documentation: https://cloud.google.com/bigquery/docs/config-yaml-translation
    * This yaml files should be placed in the path specified via the folder_output_pre_processing variable when executing the process, due to the output of the preprocessing is the input for the translation.


## Additional Instructions

* Before running the project, ensure that all required configuration files (modifiable) are correctly configured.
* Make backups of configuration files before making any modifications.
* If you have any questions or problems, consult the project documentation or contact the support team.




